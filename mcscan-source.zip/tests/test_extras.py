import json

from mcscan.evaluation import evaluate
from mcscan.history import diff_last_two, record
from mcscan.models import Finding
from mcscan.reporting import write_sarif
from mcscan.scanner import ScanResult


def _res(sid, started, rids):
    fs = [Finding(r, "t", "HIGH", "aws", "firewall", r, r, "x", "1", 14.0, True, "fix", {}, {}) for r in rids]
    return ScanResult(sid, "0.1.0", started, 0.1, "production", ["aws"], len(fs), {}, fs, [], 50.0, {})


def test_precision_recall_with_negative_control():
    truth = [{"provider": "aws", "name": "bad", "expect": ["NET-001"]},
             {"provider": "aws", "name": "ctrl", "expect": []}]
    findings = [{"provider": "aws", "resource_name": "bad", "rule_id": "NET-001"},
                {"provider": "aws", "resource_name": "ctrl", "rule_id": "NET-001"},   # false positive
                {"provider": "aws", "resource_name": "other", "rule_id": "NET-001"}]  # not in truth: ignored
    m = evaluate(findings, truth)["ALL"]
    assert (m["tp"], m["fp"], m["fn"]) == (1, 1, 0)
    assert m["precision"] == 0.5 and m["recall"] == 1.0


def test_drift_new_and_resolved(tmp_path):
    db = tmp_path / "h.db"
    record(db, _res("a", "2026-01-01T00:00:00", ["R1", "R2"]))
    record(db, _res("b", "2026-01-02T00:00:00", ["R2", "R3"]))
    d = diff_last_two(db)
    assert d["new"] == [("NET-001", "R3")] or [x[1] for x in d["new"]] == ["R3"]
    assert [x[1] for x in d["resolved"]] == ["R1"]


def test_sarif_is_valid_json_with_results(tmp_path):
    out = write_sarif(_res("a", "t", ["R1"]), tmp_path / "x.sarif")
    doc = json.loads(out.read_text())
    assert doc["version"] == "2.1.0" and len(doc["runs"][0]["results"]) == 1
