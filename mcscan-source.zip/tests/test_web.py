"""Behavior and access-boundary tests against the real API and rule engine."""
import json
import socket
import sqlite3

import pytest
from fastapi.testclient import TestClient

from mcscan.demo import DemoCollector
from mcscan.rules import RuleEngine, load_rules
from mcscan.scanner import run_scan
from mcscan.web.app import create_app

PASSWORD = "A-test-password-2026!"


@pytest.fixture
def application(tmp_path):
    app = create_app(tmp_path / "app.db")
    app.state.store.add_user("admin@example.com", "Admin", PASSWORD, "admin")
    app.state.store.add_user("member@example.com", "Member", PASSWORD)
    return app


def signed_in(app, email="admin@example.com"):
    client = TestClient(app)
    response = client.post("/api/auth/login", json={"email": email, "password": PASSWORD})
    assert response.status_code == 200
    client.headers["x-csrf-token"] = response.json()["csrf"]
    return client


def scan(client, scenario="baseline", providers=None, **options):
    return client.post("/api/scans", json={"providers": providers or ["aws", "azure", "gcp"],
                                         "scenario": scenario, **options})


def test_offline_oracle_uses_all_eight_rules_without_network(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Offline mode attempted network access")
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    engine = RuleEngine(load_rules())
    result = run_scan([DemoCollector(p) for p in ("aws", "azure", "gcp")], engine)
    assert result.resources_scanned == 34
    assert len(result.findings) == 18
    assert {f.rule_id for f in result.findings} == {r.id for r in engine.rules}
    assert not result.errors
    assert all("https" not in f.resource_name and "private" not in f.resource_name
               and "protected" not in f.resource_name and "readonly" not in f.resource_name
               for f in result.findings)
    for p in ("aws", "azure", "gcp"):
        fixed = run_scan([DemoCollector(p, hardened=True)], engine)
        assert not fixed.findings and fixed.account_score == 0


def test_cookie_session_and_csrf(application):
    client = signed_in(application)
    session = client.cookies["mcscan_session"]
    assert len(session) >= 40
    assert client.get("/api/auth/me").status_code == 200
    assert scan(client).status_code == 201
    client.headers.pop("x-csrf-token")
    assert scan(client).status_code == 403
    assert client.post("/api/auth/logout").status_code == 403
    with application.state.store.connect() as con:
        row = con.execute("SELECT token_hash FROM app_sessions").fetchone()
        assert row[0] != session


def test_scope_and_report_isolation_even_for_admin(application):
    member = signed_in(application, "member@example.com")
    result = scan(member).json()
    sid = result["scan_id"]
    admin = signed_in(application)
    assert admin.get("/api/scans").json() == []
    assert admin.get(f"/api/scans/{sid}").status_code == 404
    for kind in ("json", "html", "sarif", "csv"):
        assert admin.get(f"/api/scans/{sid}/export/{kind}").status_code == 404
    assert member.get("/api/users").status_code == 403
    assert member.get("/api/audit").status_code == 403
    assert member.post("/api/users", json={"email": "new@example.com", "name": "No",
                                         "password": PASSWORD}).status_code == 403


def test_drift_is_scope_and_criticality_specific(application):
    client = signed_in(application)
    before = scan(client).json()
    other = scan(client, providers=["aws"]).json()
    assert other["drift"]["previous_scan_id"] is None
    after = scan(client, "hardened").json()
    assert after["account_score"] == 0 and after["finding_count"] == 0
    assert after["drift"]["previous_scan_id"] == before["scan_id"]
    assert len(after["drift"]["resolved"]) == 18
    assert after["drift"]["new"] == []
    assert scan(client, criticality="dev").json()["drift"]["previous_scan_id"] is None
    again = scan(client).json()
    assert len(again["drift"]["new"]) == 18
    assert again["drift"]["previous_scan_id"] == after["scan_id"]


@pytest.mark.parametrize("kind", ["json", "html", "sarif", "csv"])
def test_exports_contain_real_scan_and_offline_labels(application, kind):
    client = signed_in(application)
    result = scan(client).json()
    response = client.get(f"/api/scans/{result['scan_id']}/export/{kind}")
    assert response.status_code == 200
    assert "attachment" in response.headers["content-disposition"]
    if kind == "json":
        assert response.json()["finding_count"] == 18 and response.json()["mode"] == "offline"
    elif kind == "html":
        assert "OFFLINE DEMO" in response.text and "aws-public-assets" in response.text
    elif kind == "sarif":
        run = response.json()["runs"][0]
        assert len(run["results"]) == 18 and run["properties"]["mode"] == "offline"
    else:
        assert "aws-public-assets" in response.text and "rule_id" in response.text


def test_member_deactivation_immediately_revokes_sessions(application):
    admin = signed_in(application)
    member = signed_in(application, "member@example.com")
    data = admin.get("/api/users").json()
    uid = next(u["id"] for u in data if u["role"] == "member")
    assert admin.patch(f"/api/users/{uid}", json={"active": False}).status_code == 200
    assert member.get("/api/auth/me").status_code == 401
    assert member.post("/api/auth/login", json={"email": "member@example.com",
                                              "password": PASSWORD}).status_code == 401
    aid = next(u["id"] for u in data if u["role"] == "admin")
    assert admin.patch(f"/api/users/{aid}", json={"active": False}).status_code == 400


def test_no_second_admin_even_under_direct_database_insert(application):
    client = signed_in(application)
    response = client.post("/api/users", json={"email": "second@example.com", "name": "Second",
                                              "password": PASSWORD, "role": "admin"})
    assert response.status_code == 201 and response.json()["role"] == "member"
    with pytest.raises(sqlite3.IntegrityError):
        application.state.store.add_user("evil@example.com", "Second admin", PASSWORD, "admin")
    assert client.post("/api/users", json={"email": "second@example.com", "name": "Duplicate",
                                          "password": PASSWORD}).status_code == 409


def test_password_change_logs_out_all_sessions(application):
    client = signed_in(application)
    other = signed_in(application)
    response = client.post("/api/auth/password", json={"current_password": PASSWORD,
                                                     "new_password": "New-strong-password-2026!"})
    assert response.status_code == 200
    assert client.get("/api/auth/me").status_code == 401
    assert other.get("/api/auth/me").status_code == 401


@pytest.mark.parametrize("body", [{"providers": []}, {"providers": ["aws", "aws"]},
                                 {"providers": ["digitalocean"]},
                                 {"providers": ["aws"], "mode": "live"}])
def test_invalid_scope_and_live_mode_rejected(application, body):
    assert signed_in(application).post("/api/scans", json=body).status_code == 422


def test_origin_rejected_and_unauthenticated_data_hidden(application):
    client = TestClient(application)
    for route in ("/api/scans", "/api/rules", "/api/users"):
        assert client.get(route).status_code == 401
    assert client.post("/api/auth/login", json={"email": "admin@example.com", "password": PASSWORD},
                       headers={"origin": "https://evil.example"}).status_code == 403
    response = client.get("/api/health")
    assert response.headers["cache-control"] == "no-store"
    assert response.headers["x-content-type-options"] == "nosniff"


def test_login_attempts_throttled(application):
    client = TestClient(application)
    for _ in range(10):
        assert client.post("/api/auth/login", json={"email": "admin@example.com",
                                                  "password": "wrong"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": "admin@example.com",
                                              "password": "wrong"}).status_code == 429


def test_data_survives_app_restart(application):
    original = signed_in(application)
    result = scan(original).json()
    restarted = create_app(application.state.store.path)
    client = signed_in(restarted)
    saved = client.get("/api/scans/" + result["scan_id"]).json()
    assert saved["finding_count"] == 18 and len(saved["resources"]) == 34
    assert json.dumps(saved["findings"]) == json.dumps(result["findings"])
