"""End-to-end test oracle: seed known misconfigurations, scan, fix, rescan."""
import json

import boto3
from moto import mock_aws

from mcscan.cli import main
from mcscan.collectors.aws import AwsCollector
from mcscan.rules import RuleEngine, load_rules
from mcscan.scanner import run_scan

ADMIN = {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]}
EXPECTED_BEFORE = {
    ("STOR-001", "aws-pub-bucket"), ("IAM-001", "admin-all"), ("NET-001", "open-ssh"),
    ("NET-002", "open-pg"), ("ENC-001", "vol"), ("ENC-002", "db1"), ("NET-003", "db1"),
}


def seed():
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="aws-pub-bucket")
    s3.put_bucket_acl(Bucket="aws-pub-bucket", ACL="public-read")
    s3.create_bucket(Bucket="aws-private-bucket")
    ec2 = boto3.client("ec2", region_name="us-east-1")
    world = [{"CidrIp": "0.0.0.0/0"}]
    ssh = ec2.create_security_group(GroupName="open-ssh", Description="x")["GroupId"]
    ec2.authorize_security_group_ingress(GroupId=ssh, IpPermissions=[
        {"IpProtocol": "tcp", "FromPort": 22, "ToPort": 22, "IpRanges": world}])
    pg = ec2.create_security_group(GroupName="open-pg", Description="x")["GroupId"]
    ec2.authorize_security_group_ingress(GroupId=pg, IpPermissions=[
        {"IpProtocol": "tcp", "FromPort": 5432, "ToPort": 5432, "IpRanges": world}])
    vol = ec2.create_volume(AvailabilityZone="us-east-1a", Size=1, Encrypted=False)["VolumeId"]
    ec2.create_tags(Resources=[vol], Tags=[{"Key": "Name", "Value": "vol"}])
    iam = boto3.client("iam")
    arn = iam.create_policy(PolicyName="admin-all", PolicyDocument=json.dumps(ADMIN))["Policy"]["Arn"]
    boto3.client("rds", region_name="us-east-1").create_db_instance(
        DBInstanceIdentifier="db1", DBInstanceClass="db.t3.micro", Engine="postgres",
        MasterUsername="u", MasterUserPassword="password123", AllocatedStorage=20,
        StorageEncrypted=False, PubliclyAccessible=True)
    return {"ssh": ssh, "pg": pg, "vol": vol, "arn": arn}


def fix(ids):
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.put_bucket_acl(Bucket="aws-pub-bucket", ACL="private")
    ec2 = boto3.client("ec2", region_name="us-east-1")
    for sg, port in ((ids["ssh"], 22), (ids["pg"], 5432)):
        ec2.revoke_security_group_ingress(GroupId=sg, IpPermissions=[
            {"IpProtocol": "tcp", "FromPort": port, "ToPort": port, "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}])
    ec2.delete_volume(VolumeId=ids["vol"])
    boto3.client("iam").delete_policy(PolicyArn=ids["arn"])
    boto3.client("rds", region_name="us-east-1").delete_db_instance(
        DBInstanceIdentifier="db1", SkipFinalSnapshot=True)


def scan():
    return run_scan([AwsCollector(regions=["us-east-1"])], RuleEngine(load_rules()))


def named(result):
    out = set()
    for f in result.findings:
        out.add((f.rule_id, "vol" if f.resource_type == "block_volume" else f.resource_name))
    return out


@mock_aws
def test_before_after_oracle():
    ids = seed()
    before = scan()
    assert named(before) == EXPECTED_BEFORE, "detected set must equal seeded set (0 FP, 0 FN)"
    assert before.errors == []
    assert before.account_score > 70
    fix(ids)
    after = scan()
    assert after.findings == []
    assert after.account_score == 0.0


@mock_aws
def test_cli_exit_code_and_report_files(tmp_path, capsys):
    seed()
    rc = main(["scan", "--provider", "aws", "--region", "us-east-1", "--format", "json", "html",
               "--out", str(tmp_path), "--fail-on", "HIGH"])
    assert rc == 2  # CI gate trips on HIGH+
    data = json.loads(next(tmp_path.glob("*.json")).read_text())
    assert data["account_score"] > 70 and data["findings"]
    html = next(tmp_path.glob("*.html")).read_text()
    assert "aws-pub-bucket" in html


def test_html_report_escapes_hostile_names(tmp_path):
    from mcscan.models import Finding
    from mcscan.reporting import write_html
    from mcscan.scanner import ScanResult
    f = Finding("STOR-001", "t", "CRITICAL", "aws", "storage_bucket", "id", "<script>alert(1)</script>",
                "r", "1", 30.0, True, "fix <b>it</b>", {}, {})
    res = ScanResult("sid", "0.1.0", "now", 0.1, "production", ["aws"], 1, {}, [f], [], 40.0, {})
    out = write_html(res, tmp_path / "r.html").read_text()
    assert "<script>alert(1)</script>" not in out
    assert "&lt;script&gt;" in out
