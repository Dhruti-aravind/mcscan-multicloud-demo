import pytest

from mcscan.risk import account_score, finding_score


def test_finding_score_formula():
    assert finding_score("CRITICAL", True, "production") == 10 * 2.0 * 1.5
    assert finding_score("LOW", False, "dev") == 0.5


def test_account_score_bounds_and_monotonic():
    assert account_score([]) == 0.0
    assert 0 < account_score([30]) < account_score([30, 30]) < 100
    assert account_score([10_000]) <= 100.0


def test_unknown_severity_rejected():
    with pytest.raises(ValueError):
        finding_score("SEVERE", True)
