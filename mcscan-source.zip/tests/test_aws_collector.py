import json

import boto3
from moto import mock_aws

from mcscan.collectors.aws import (
    AwsCollector,
    iam_document_flags,
    policy_public_access,
    world_ingress_entries,
)

ADMIN = {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]}


def test_policy_public_access_parsing():
    pub = {"Statement": [{"Effect": "Allow", "Principal": "*", "Action": "s3:GetObject", "Resource": "*"}]}
    assert policy_public_access(pub) == (True, False)
    cond = {"Statement": [{"Effect": "Allow", "Principal": "*", "Action": "s3:*", "Condition": {"IpAddress": {}}}]}
    assert policy_public_access(cond) == (False, False)  # documented limitation
    wr = {"Statement": {"Effect": "Allow", "Principal": {"AWS": "*"}, "Action": ["s3:PutObject"]}}
    assert policy_public_access(wr) == (False, True)


def test_iam_flags_are_per_statement():
    split = {"Statement": [
        {"Effect": "Allow", "Action": "*", "Resource": "arn:aws:s3:::only-this"},
        {"Effect": "Allow", "Action": "s3:GetObject", "Resource": "*"},
    ]}
    assert iam_document_flags(split) == (False, False)  # '*' and '*' are in DIFFERENT statements
    assert iam_document_flags(ADMIN) == (True, False)
    assert iam_document_flags({"Statement": [{"Effect": "Allow", "Action": "s3:*", "Resource": "*"}]}) == (False, True)


def test_world_ingress_ipv6_and_all_protocols():
    perms = [
        {"IpProtocol": "-1", "IpRanges": [{"CidrIp": "0.0.0.0/0"}]},
        {"IpProtocol": "tcp", "FromPort": 22, "ToPort": 22, "Ipv6Ranges": [{"CidrIpv6": "::/0"}]},
        {"IpProtocol": "tcp", "FromPort": 443, "ToPort": 443, "IpRanges": [{"CidrIp": "10.0.0.0/8"}]},
    ]
    out = world_ingress_entries(perms)
    assert {"protocol": "all", "from": 0, "to": 65535} in out
    assert {"protocol": "tcp", "from": 22, "to": 22} in out
    assert len(out) == 2


@mock_aws
def test_collects_all_resource_types_and_normalizes():
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="pub-bucket")
    s3.put_bucket_acl(Bucket="pub-bucket", ACL="public-read")
    s3.create_bucket(Bucket="private-bucket")
    ec2 = boto3.client("ec2", region_name="us-east-1")
    sg = ec2.create_security_group(GroupName="open-ssh", Description="x")["GroupId"]
    ec2.authorize_security_group_ingress(GroupId=sg, IpPermissions=[
        {"IpProtocol": "tcp", "FromPort": 22, "ToPort": 22, "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}])
    ec2.create_volume(AvailabilityZone="us-east-1a", Size=1, Encrypted=False)
    boto3.client("iam").create_policy(PolicyName="admin-all", PolicyDocument=json.dumps(ADMIN))

    collector = AwsCollector(regions=["us-east-1"])
    resources = list(collector.collect())
    for r in resources:
        r.validate()  # schema contract holds
    by_name = {r.name: r for r in resources}
    assert by_name["pub-bucket"].properties["public_read"] is True
    assert by_name["private-bucket"].properties["public_read"] is False
    assert by_name["open-ssh"].properties["internet_exposed"] is True
    assert by_name["admin-all"].properties["allows_admin"] is True
    assert any(r.resource_type == "block_volume" and not r.properties["encrypted_at_rest"] for r in resources)
    assert collector.errors == []


@mock_aws
def test_block_public_access_neutralizes_public_acl():
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="blocked")
    s3.put_bucket_acl(Bucket="blocked", ACL="public-read")
    s3.put_public_access_block(Bucket="blocked", PublicAccessBlockConfiguration={
        "BlockPublicAcls": True, "IgnorePublicAcls": True,
        "BlockPublicPolicy": True, "RestrictPublicBuckets": True})
    res = next(r for r in AwsCollector().collect() if r.name == "blocked")
    assert res.properties["public_read"] is False


@mock_aws
def test_access_denied_on_one_service_gives_partial_scan_not_crash(monkeypatch):
    boto3.client("s3", region_name="us-east-1").create_bucket(Bucket="ok-bucket")
    collector = AwsCollector()

    def boom(self, region):
        from botocore.exceptions import ClientError
        yield from ()  # makes this a generator, like the real collector methods
        raise ClientError({"Error": {"Code": "AccessDenied", "Message": "nope"}}, "DescribeVolumes")

    monkeypatch.setattr(AwsCollector, "_volumes", boom)
    names = [r.name for r in collector.collect()]
    assert "ok-bucket" in names
    assert any("AccessDenied" in e for e in collector.errors)
