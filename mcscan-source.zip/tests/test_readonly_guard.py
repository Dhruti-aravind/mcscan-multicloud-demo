"""Design guarantee: collectors never call a mutating cloud API. Enforced statically."""
import ast
import re
from pathlib import Path

MUTATING = re.compile(
    r"^(create|put|delete|update|modify|attach|detach|set|add|remove|start|stop|terminate|run|"
    r"authorize|revoke|reboot|enable|disable|tag|untag|upload|insert|patch|apply)_"
)
COLLECTORS = Path(__file__).parents[1] / "src" / "mcscan" / "collectors"


def test_collectors_only_call_read_apis():
    offenders = []
    for path in COLLECTORS.glob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            is_attr_call = isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            if is_attr_call and MUTATING.match(node.func.attr):
                offenders.append(f"{path.name}:{node.lineno} {node.func.attr}")
    assert offenders == [], offenders
