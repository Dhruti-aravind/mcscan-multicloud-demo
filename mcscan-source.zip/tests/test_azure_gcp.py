from types import SimpleNamespace

from mcscan.collectors.azure import (
    AzureCollector,
    nsg_world_ingress,
    role_flags,
    storage_public_flags,
)
from mcscan.collectors.gcp import (
    GcpCollector,
    binding_flags,
    bucket_public_flags,
    firewall_world_ingress,
)
from mcscan.rules import RuleEngine, load_rules
from mcscan.scanner import run_scan


def test_azure_nsg_world_ssh_and_ranges():
    rules = [
        {"name": "ssh", "properties": {"direction": "Inbound", "access": "Allow", "protocol": "Tcp",
         "source_address_prefix": "*", "destination_port_range": "22"}},
        {"name": "web", "properties": {"direction": "Inbound", "access": "Allow", "protocol": "Tcp",
         "source_address_prefix": "Internet", "destination_port_ranges": ["80", "8000-9000"]}},
        {"name": "internal", "properties": {"direction": "Inbound", "access": "Allow", "protocol": "Tcp",
         "source_address_prefix": "10.0.0.0/8", "destination_port_range": "22"}},
        {"name": "deny", "properties": {"direction": "Inbound", "access": "Deny", "protocol": "*",
         "source_address_prefix": "*", "destination_port_range": "*"}},
    ]
    out = nsg_world_ingress(rules)
    assert {"protocol": "tcp", "from": 22, "to": 22} in out
    assert {"protocol": "tcp", "from": 8000, "to": 9000} in out
    assert len(out) == 3


def test_azure_storage_and_roles():
    assert storage_public_flags({"allow_blob_public_access": False}, [{"public_access": "Blob"}]) == (False, False)
    assert storage_public_flags({"allow_blob_public_access": True}, [{"public_access": "Container"}]) == (True, False)
    assert storage_public_flags({"allow_blob_public_access": True}, [{"public_access": "None"}]) == (False, False)
    assert role_flags({"permissions": [{"actions": ["*"]}]}) == (True, False)
    assert role_flags({"permissions": [{"actions": ["Microsoft.Storage/*"]}]}) == (False, True)
    assert role_flags({"permissions": [{"actions": ["Microsoft.Storage/storageAccounts/read"]}]}) == (False, False)


def test_gcp_normalizers():
    b = [{"role": "roles/storage.objectViewer", "members": ["allUsers"]}]
    assert bucket_public_flags(b, pap_enforced=False) == (True, False)
    assert bucket_public_flags(b, pap_enforced=True) == (False, False)
    fw = {"direction": "INGRESS", "source_ranges": ["0.0.0.0/0"],
          "allowed": [{"I_p_protocol": "tcp", "ports": ["22", "8000-8100"]}]}
    out = firewall_world_ingress(fw)
    assert {"protocol": "tcp", "from": 22, "to": 22} in out and len(out) == 2
    assert firewall_world_ingress({**fw, "disabled": True}) == []
    assert firewall_world_ingress({**fw, "source_ranges": ["10.0.0.0/8"]}) == []
    assert binding_flags("roles/owner") == (True, False) and binding_flags("roles/viewer") == (False, False)


class FakeAzure:
    def __init__(self):
        acct = {"id": "/subscriptions/s/resourceGroups/rg/providers/Microsoft.Storage/storageAccounts/pubacct",
                "name": "pubacct", "location": "eastus", "allow_blob_public_access": True}
        self.storage_accounts = SimpleNamespace(list=lambda: [acct])
        self.blob_containers = SimpleNamespace(list=lambda rg, name: [{"name": "c", "public_access": "Blob"}])
        self.network_security_groups = SimpleNamespace(list_all=lambda: [{
            "id": "n1", "name": "open-ssh", "location": "eastus", "security_rules": [
                {"direction": "Inbound", "access": "Allow", "protocol": "Tcp",
                 "source_address_prefix": "*", "destination_port_range": "22"}]}])
        self.role_definitions = SimpleNamespace(list=lambda scope, filter=None: [
            {"id": "r1", "name": "x", "role_name": "all-admin", "permissions": [{"actions": ["*"]}]}])
        self.disks = SimpleNamespace(list=lambda: [{"id": "d1", "name": "disk1", "location": "eastus"}])


def test_azure_collector_end_to_end_with_fake_clients():
    fake = FakeAzure()
    col = AzureCollector("s", clients={"storage": fake, "network": fake, "auth": fake, "compute": fake})
    res = run_scan([col], RuleEngine(load_rules()))
    got = {(f.rule_id, f.resource_name) for f in res.findings}
    assert got == {("STOR-001", "pubacct"), ("NET-001", "open-ssh"), ("IAM-001", "all-admin")}
    assert res.errors == []


def test_gcp_collector_end_to_end_with_fake_clients():
    bucket = SimpleNamespace(
        name="pub-gcs", location="US",
        iam_configuration=SimpleNamespace(public_access_prevention="inherited"),
        get_iam_policy=lambda requested_policy_version=3: SimpleNamespace(bindings=[
            {"role": "roles/storage.objectViewer", "members": {"allUsers"}}]))
    storage = SimpleNamespace(list_buckets=lambda: [bucket])
    fw = {"id": 1, "name": "open-ssh", "direction": "INGRESS", "source_ranges": ["0.0.0.0/0"],
          "allowed": [{"ip_protocol": "tcp", "ports": ["22"]}]}
    firewalls = SimpleNamespace(list=lambda project: [fw])
    projects = SimpleNamespace(get_iam_policy=lambda request: SimpleNamespace(bindings=[
        SimpleNamespace(role="roles/owner", members=["user:a@x.com"]),
        SimpleNamespace(role="roles/viewer", members=["user:b@x.com"])]))
    disks = SimpleNamespace(aggregated_list=lambda project: [("zones/z1", SimpleNamespace(disks=[]))])
    col = GcpCollector("p", clients={"storage": storage, "firewalls": firewalls, "projects": projects,
                                     "disks": disks, "to_dict": lambda d: d})
    res = run_scan([col], RuleEngine(load_rules()))
    got = {(f.rule_id, f.resource_name) for f in res.findings}
    assert got == {("STOR-001", "pub-gcs"), ("NET-001", "open-ssh"), ("IAM-001", "roles/owner")}
    assert res.errors == []


def test_same_rules_fire_on_all_three_clouds():
    """Cross-cloud consistency: one logical misconfig -> same rule ID + severity on every provider."""
    from mcscan.evaluation import parity
    fa = FakeAzure()
    az = run_scan([AzureCollector("s", clients={"storage": fa, "network": fa, "auth": fa, "compute": fa})],
                  RuleEngine(load_rules()))
    findings = [f.to_dict() for f in az.findings]
    findings.append({"provider": "aws", "resource_name": "aws-pub", "rule_id": "STOR-001", "severity": "CRITICAL"})
    cases = [{"id": "public-storage", "rule": "STOR-001", "severity": "CRITICAL",
              "members": {"aws": "aws-pub", "azure": "pubacct"}}]
    assert parity(findings, cases) == 1.0
