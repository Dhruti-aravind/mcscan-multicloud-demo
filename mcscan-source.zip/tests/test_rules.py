import pytest

from mcscan.models import BENIGN_DEFAULTS, Resource
from mcscan.rules import RuleEngine, RuleError, load_rules, port_exposed

RULES = load_rules()
CASES = [(r, t) for r in RULES for t in r.tests]


def test_catalog_has_expected_rules():
    ids = {r.id for r in RULES}
    assert {"STOR-001", "IAM-001", "IAM-002", "ENC-001", "ENC-002", "NET-001", "NET-002", "NET-003"} <= ids


@pytest.mark.parametrize("rule,case", CASES, ids=[f"{r.id}-{i}" for i, (r, _) in enumerate(CASES)])
def test_rule_embedded_cases(rule, case):
    props = {**BENIGN_DEFAULTS[rule.resource_type], **case["props"]}
    assert rule.matches(props) is case["expect"]


def test_every_rule_has_positive_and_negative_case():
    for r in RULES:
        outcomes = {t["expect"] for t in r.tests}
        assert outcomes == {True, False}, f"{r.id} needs both a matching and non-matching test"


def test_port_exposed_ranges():
    assert port_exposed([{"protocol": "tcp", "from": 20, "to": 30}], [22])
    assert not port_exposed([{"protocol": "tcp", "from": 23, "to": 30}], [22])


def test_bad_rule_is_rejected_at_load(tmp_path):
    (tmp_path / "bad.yaml").write_text(
        "id: BAD-001\ntitle: t\nseverity: HIGH\nresource_type: storage_bucket\n"
        "providers: [aws]\ncondition: 'public_reed'\n"
    )
    with pytest.raises(RuleError):
        load_rules(tmp_path)


def test_condition_cannot_run_arbitrary_code(tmp_path):
    (tmp_path / "evil.yaml").write_text(
        "id: EVL-001\ntitle: t\nseverity: HIGH\nresource_type: storage_bucket\n"
        "providers: [aws]\ncondition: \"__import__('os').system('echo pwned')\"\n"
    )
    with pytest.raises(RuleError):
        load_rules(tmp_path)


def test_engine_reports_missing_property_instead_of_crashing():
    res = Resource("aws", "storage_bucket", "b", "b", "us-east-1", "1", properties={})
    matched, errors = RuleEngine(RULES).evaluate(res)
    assert matched == [] and errors
