# Build verification — 14 October 2026

Tested on Windows, Python 3.12.4, Node.js 22.15.1 and npm 10.9.2.

## Automated checks

- **65 tests passed**: the original 47 offline scanner tests and 18 additional API/demo test cases.
- **85% Python coverage** (80% gate passed). Ruff: all checks passed.
- Eight YAML rules load and lint successfully.
- TypeScript type checking and Vite production build succeed with React and the real `motion/react` dependency.
- Offline CLI before/after scans: 18 findings to zero, 18 resolved in drift history.
- CLI severity gate: baseline returns 2 for `--fail-on HIGH`; hardened returns 0.
- JSON, HTML, SARIF and CSV exports tested through the authenticated API. Offline labeling tested for applicable formats.
- Tested session authentication/CSRF/origin restrictions, login throttling, member restrictions, scan/report ownership including admin denial, one-admin uniqueness, password/session revocation, deactivation, persistence, invalid scope/live-mode rejection, and provider/criticality-specific drift.
- The demo oracle forbids socket connections during collection/evaluation and validates all eight rules and safe negative controls.

The dependency stack emits a Starlette warning about its future HTTP test-client adapter. It does not fail these tests.

## Offline fixture results

| Provider | Resources | Baseline findings | Hardened findings | Baseline risk | Hardened risk |
| --- | --- | --- | --- | --- | --- |
| AWS | 12 | 8 | 0 | 95.8 | 0 |
| Azure | 11 | 5 | 0 | 88.1 | 0 |
| GCP | 11 | 5 | 0 | 88.1 | 0 |
| Combined | 34 | 18 | 0 | 99.9 | 0 |

Production criticality, nine critical, six high and three medium baseline findings. Sample CLI reports are included under `examples/before/` and `examples/after/`. These are hand-built synthetic cases and establish no general accuracy claim.

## Browser checks

Verified in the Codex browser against the built UI and live local FastAPI server:

- Administrator sign-in and sign-out; member sign-in with an empty, isolated workspace and no administration menu.
- Three-provider baseline scan; computed summary, cloud scores and severity counts.
- Combined cloud/severity/search filters reduced findings to the expected Azure public bucket.
- Finding detail dialog with Azure-specific remediation and normalized evidence.
- Hardened scan: zero findings and score zero; history shows 18 resolved from the matching baseline.
- Earlier scans can be selected for inspection.
- Desktop appearance and a 390 × 844 phone layout inspected; fixed overflow and ensured sidebar account controls remain reachable on short screens.

## Not executed

Real AWS, Azure and GCP calls, Terraform apply/validate, Prowler comparison, GitHub Actions runs, Docker image builds and hosted load/security testing. Configuration files are included for later validation. No cloud resource was created, changed or deleted during this build. The multi-user web API supports only offline scans in this release.
