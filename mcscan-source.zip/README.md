# mcscan — Cloud security, in focus.

An offline-first multi-cloud scanner with a React/TypeScript + Motion dashboard, FastAPI API, and SQLite persistence. Extends the engine, eight YAML rules, collectors and Terraform templates supplied in `mcscan-full.zip`. The UI takes visual inspiration from Motion's bold typography, yellow accents and animated line fields and uses the open-source `motion/react` package. No paid Motion+ components or remote assets are needed.

## Host on Streamlit Community Cloud

`streamlit_app.py` mounts the same React + Motion dashboard as a Streamlit Components v2 component. Its browser requests cross the component bridge to the existing FastAPI app inside the Streamlit process, so the Python rule engine still computes the offline scans. The browser's Streamlit session holds its own API client and cookies; the API continues to enforce its existing roles and scan ownership.

1. Put this folder in a GitHub repository. The compiled component assets in `src/mcscan/streamlit_component/assets/` are included; no Node build is needed on Streamlit Cloud. Keep `.data/`, `.streamlit/secrets.toml`, and credentials out of Git.
2. In [Streamlit Community Cloud](https://share.streamlit.io/), create an app from the repository with `streamlit_app.py` as the entrypoint and Python 3.12. Streamlit installs `requirements.txt` automatically.
3. In the app's **Advanced settings → Secrets**, enter root-level values like these, using your own email and a unique password of at least 12 characters:

   ```toml
   MCSCAN_ADMIN_EMAIL = "you@example.com"
   MCSCAN_ADMIN_NAME = "Administrator"
   MCSCAN_ADMIN_PASSWORD = "choose-a-long-unique-password"
   ```

   The first run creates the sole administrator. Admins create member accounts in **Team members**. The password is kept in Streamlit's secret settings, not the repository. Change it in the dashboard after first sign-in if desired.

4. For scan history and accounts that must survive Community Cloud restarts, also provide a managed PostgreSQL connection string as a root-level `DATABASE_URL` secret. Without it, the app uses local SQLite, which [Streamlit Cloud does not guarantee to retain](https://docs.streamlit.io/develop/concepts/connections/connecting-to-data). This is suitable only for a disposable demo. PostgreSQL support uses the same ownership and single-admin rules.

To run this hosted entrypoint locally, install `requirements.txt`, set the three administrator environment variables, then run `streamlit run streamlit_app.py`. Rebuild the embedded Motion UI after source changes with `npm run build:streamlit` from `frontend/`, and commit the generated component assets.

The demo processes **34 synthetic resources and computes 18 findings**: AWS 8, Azure 5, GCP 5. Hardened fixtures return zero findings. These are fixture-set results, not measurements of live-cloud accuracy.

## Start on Windows

Requires Python 3.12 and Node.js 22 (tested). In PowerShell, open this folder and run:

```powershell
.\start.ps1 -Demo
```

Open **http://127.0.0.1:8000**. The script installs pinned Python dependencies into a project `.venv` and serves the app. The release includes compiled UI files. To rebuild changed UI source, run `npm ci` and `npm run build` in `frontend/`. If script execution is blocked, use the manual commands below; changing execution policy is unnecessary.

### Manual setup

```bash
python -m venv .venv
# Windows: use .venv\Scripts\python.exe instead of .venv/bin/python
.venv/bin/python -m pip install -c requirements.lock -e '.[web]'
# Only needed if frontend/dist is absent or UI source changed:
cd frontend
npm ci
npm run build
cd ..
.venv/bin/python -m mcscan.web --demo
```

Use the demo buttons on the sign-in page, or these disposable accounts:

| Role | Email | Password |
| --- | --- | --- |
| Administrator | admin@mcscan.local | Mcscan-Demo-2026! |
| Member | analyst@mcscan.local | Analyst-Demo-2026! |

`--demo` refuses a non-loopback host. It uses `.data/demo.db`, separate from the regular `.data/app.db`. Restarting preserves users and scans. The packaged ZIP contains no account database or session tokens.

## Walk through the demo

1. Sign in as administrator, choose **New scan**, all three clouds and **Baseline**. The real rule engine returns 18 findings across 34 resources.
2. Filter/search **Findings** and open a row for evidence and remediation. **Resources** includes safe negative controls. **Rule library** explains actual provider coverage.
3. Run **Hardened** with the same provider selection and criticality. The score becomes zero; **Scan history** shows 18 resolved. Opening a past scan changes the selected results for every view and export.
4. Download HTML, JSON, SARIF or CSV. HTML/JSON/SARIF explicitly identify offline results.
5. Use **Team members** to create/deactivate/reactivate members. **Activity log** records sign-ins, scans, exports and account administration.
6. Sign out and try the member account. It has a separate scan workspace and no administration access. Members can change their password in Settings.

## Multiple end users, single administrator

- Exactly one administrator, enforced by a SQLite unique partial index. The administrator manages members, sees scan counts and views the shared audit metadata.
- Every user's scan contents, resources, findings, reports and history are private to that owner. **Even the administrator's scan endpoints cannot read another member's scan contents.**
- No public signup, role-promotion API or second administrator. New accounts are always members. The only administrator cannot be deactivated.
- Passwords use salted scrypt. Random opaque session tokens are stored hashed, issued in HttpOnly/SameSite cookies and expire after 12 hours. CSRF tokens, same-origin checks and login throttling protect API writes. No session token is stored in browser localStorage.
- Deactivation revokes sessions immediately. Password changes revoke all sessions for that account. Account reactivation retains scans.
- Email delivery, password recovery and MFA are not implemented. The administrator creates initial member credentials and shares them outside the app.

For your own accounts, start without demo credentials:

```powershell
.venv\Scripts\python.exe -m mcscan.web --init-admin --email you@example.com --name "Your Name"
# Enter and confirm a password interactively (12+ characters).
.venv\Scripts\python.exe -m mcscan.web
```

`--init-admin` refuses to create a second admin. Use `--db path/to/database.db` consistently for a custom database. Configure the server with `--host` / `--port` (loopback:8000 by default).

## Architecture

```mermaid
flowchart LR
  UI[React + TypeScript + Motion] --> API[FastAPI / sessions / ownership]
  API --> D[Offline fixture collectors]
  D --> N[Normalized resource schema]
  YAML[8 YAML rules] --> E[Shared rule engine]
  N --> E --> R[Risk scorer]
  R --> API
  API --> DB[(SQLite users / sessions / scans / audit)]
  API --> O[JSON / HTML / SARIF / CSV]
  CLI[CLI] --> L[Live AWS / Azure / GCP collectors]
  CLI --> D
  L --> N
```

`src/mcscan/demo.py` uses synthetic data; Azure/GCP pass through the supplied pure normalizers. AWS demo resources are normalized fixtures. Separate existing moto tests exercise the AWS SDK fetch layer. Offline scans never read cloud credentials or make cloud calls.

`src/mcscan/web/` adds authentication, role checks, persistent snapshots, scope-aware drift and administration. `frontend/src/` adds responsive views, keyboard-accessible dialogs, reduced-motion support and Motion entrance/layout/gesture/SVG animations. The original CLI, collectors, evaluation scripts and Terraform files are retained.

Finding risk = severity × exposure × criticality. Severity weights: Critical 10, High 7, Medium 4, Low 1. Exposure: internet 2, otherwise 1. Criticality: production 1.5, staging 1, development 0.5. Overall score = `100 * (1 - exp(-sum / 50))`. Higher means more detected risk; this is not a calibrated probability or compliance certification.

Web drift compares the most recent scan by the **same user, provider selection and criticality**. Finding keys include provider, resource ID and rule ID. The first scan in a scope has no baseline. The UI lists up to 200 recent scans; older snapshots remain in SQLite. The original optional CLI history database is separate.

## Rules

| Rule | Severity | Condition | Effective coverage |
| --- | --- | --- | --- |
| STOR-001 | Critical | Public object storage | AWS, Azure, GCP |
| NET-001 | Critical | World-open SSH/RDP | AWS, Azure, GCP |
| NET-002 | Critical | World-open database ports | AWS, Azure, GCP |
| IAM-001 | High | Administrative wildcard / owner access | AWS, Azure, GCP (different semantics) |
| IAM-002 | Medium | Broad service wildcard / editor access | AWS, Azure, GCP |
| ENC-001 | High | Unencrypted block volume | Can fire on AWS; Azure/GCP encrypted by default |
| ENC-002 | High | Unencrypted database | AWS only; other database collectors absent |
| NET-003 | High | Public database | AWS only; other database collectors absent |

Add YAML rules with positive/negative cases under `src/mcscan/rules/`, run `mcscan rules lint`, then restart the API to reload. Findings are configuration signals; they do not prove exploitability or actual network reachability.

## Offline CLI

```bash
mcscan rules lint
mcscan scan --provider aws azure gcp --demo baseline --format cli json html sarif --out reports/before --history-db history.db
mcscan scan --provider aws azure gcp --demo hardened --format cli json html sarif --out reports/after --history-db history.db
```

`--fail-on HIGH` exits 2 for HIGH or CRITICAL findings. JSON/SARIF include validation mode; HTML labels synthetic results.

## Later: real cloud accounts

Live scans are **disabled in the multi-user web API**. Clients cannot submit credentials, endpoint URLs or a live mode. Original live CLI collectors are retained:

```bash
pip install -e '.[azure,gcp]'
mcscan scan --provider aws --region us-east-1 --format cli json html
mcscan scan --provider azure --azure-subscription-id YOUR_ID --format cli json html
mcscan scan --provider gcp --gcp-project-id YOUR_PROJECT --format cli json html
```

Configure your read-only SDK identities when ready. Do not commit credentials. This build does not create cloud accounts or apply Terraform. The included `infra/terraform/` templates intentionally seed issues and require review/validation before a sandbox deployment. Real cloud calls and Terraform have **not** been executed here. Per-user cloud identities and account authorization are required before enabling live web scanning.

## Docker

```bash
docker compose build
docker compose run --rm mcscan python -m mcscan.web --init-admin --email admin@example.com
docker compose up -d
```

The image runs unprivileged, persists SQLite in a named volume and starts without demo accounts. Compose exposes loopback only and mounts no cloud credentials. Docker definitions are provided but were not executed on this machine.

For hosting, use an HTTPS reverse proxy, set `MCSCAN_ALLOWED_HOSTS` to the actual hostname and `MCSCAN_SECURE_COOKIES=1`. Back up the data volume. This is a single-process local release; large-scale hosting, organization tenancy, MFA, recovery and a background job queue need additional work.

## Develop and verify

```bash
python -m pip install -c requirements.lock -e '.[dev,web]'
ruff check src tests
mcscan rules lint
pytest --cov=mcscan --cov-fail-under=80
cd frontend
npm ci
npm run build
```

For frontend development use `npm run dev` while the API runs on port 8000; Vite proxies `/api` so sessions remain same-origin. Production serves UI/API from the same FastAPI origin. `requirements.lock` and `frontend/package-lock.json` capture tested versions. CI runs offline Python checks and the frontend build, without cloud credentials. See `VALIDATION.md` for measured results from this build.

## Known limitations

Only eight checks; no general coverage/accuracy claim or Prowler comparison. Supplied live collector limits remain: conditional S3 policies and IAM NotAction/NotResource are not fully interpreted; unattached open security groups can be flagged; Azure NSG priority/Deny interplay is ignored; Azure/GCP database collectors are absent. GCP Owner/Editor findings are a policy choice. Live IAM semantics and reachability need validation.

There is no automatic cloud remediation. Hardened scans use changed synthetic fixtures. UI counts come from scanner output; no historical values or live benchmarks are fabricated.

## License

Apache-2.0, as declared in the supplied scanner package; standard text is in `LICENSE`. Dependencies retain their upstream licenses. Original source provenance: the user-supplied `mcscan-full.zip` and build guide.
