# Sandbox for mcscan. One switch: insecure=true seeds misconfigurations, false fixes them.
# Use a DEDICATED sandbox account. Everything is tagged project=mcscan.
terraform {
  required_providers {
    aws    = { source = "hashicorp/aws" }
    random = { source = "hashicorp/random" }
  }
}
variable "region" { default = "us-east-1" }
variable "insecure" {
  type    = bool
  default = true
}
provider "aws" {
  region = var.region
  default_tags { tags = { project = "mcscan" } }
}
data "aws_availability_zones" "az" {}
resource "random_id" "s" { byte_length = 4 }

# --- STOR-001: public bucket (ACL public-read). Holds NO data.
resource "aws_s3_bucket" "target" {
  bucket        = "mcscan-target-${random_id.s.hex}"
  force_destroy = true
}
resource "aws_s3_bucket_public_access_block" "target" {
  bucket                  = aws_s3_bucket.target.id
  block_public_acls       = !var.insecure
  block_public_policy     = !var.insecure
  ignore_public_acls      = !var.insecure
  restrict_public_buckets = !var.insecure
}
resource "aws_s3_bucket_ownership_controls" "target" {
  bucket = aws_s3_bucket.target.id
  rule { object_ownership = "BucketOwnerPreferred" }
}
resource "aws_s3_bucket_acl" "target" {
  count      = var.insecure ? 1 : 0
  bucket     = aws_s3_bucket.target.id
  acl        = "public-read"
  depends_on = [aws_s3_bucket_ownership_controls.target, aws_s3_bucket_public_access_block.target]
}
# NEGATIVE CONTROL: private bucket with Block Public Access on. Must NOT fire.
resource "aws_s3_bucket" "control" {
  bucket        = "mcscan-control-${random_id.s.hex}"
  force_destroy = true
}
resource "aws_s3_bucket_public_access_block" "control" {
  bucket                  = aws_s3_bucket.control.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# --- NET-001 / NET-002: world-open SSH and Postgres (security groups attached to nothing)
resource "aws_security_group" "ssh" {
  name        = "mcscan-open-ssh"
  description = "mcscan sandbox"
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.insecure ? "0.0.0.0/0" : "10.0.0.0/8"]
  }
}
resource "aws_security_group" "pg" {
  name        = "mcscan-open-pg"
  description = "mcscan sandbox"
  ingress {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = [var.insecure ? "0.0.0.0/0" : "10.0.0.0/8"]
  }
}
# NEGATIVE CONTROL: world-open HTTPS only. Must NOT fire NET-001/002.
resource "aws_security_group" "web" {
  name        = "mcscan-web-443"
  description = "mcscan sandbox control"
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# --- IAM-001: admin wildcard policy (not attached to anyone)
resource "aws_iam_policy" "admin" {
  name = "mcscan-admin-all"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = var.insecure ? "*" : "s3:ListAllMyBuckets"
      Resource = "*"
    }]
  })
}

# --- ENC-001: 1 GiB volume, unencrypted when insecure (tiny cost, destroy after demo)
resource "aws_ebs_volume" "vol" {
  availability_zone = data.aws_availability_zones.az.names[0]
  size              = 1
  encrypted         = !var.insecure
  tags              = { Name = "mcscan-vol" }
}
output "bucket" { value = aws_s3_bucket.target.bucket }
