# Azure sandbox. insecure=true seeds misconfigurations. Use the Azure for Students subscription.
terraform {
  required_providers {
    azurerm = { source = "hashicorp/azurerm" }
    random  = { source = "hashicorp/random" }
  }
}
variable "subscription_id" {}
variable "location" { default = "eastus" }
variable "insecure" {
  type    = bool
  default = true
}
provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}
resource "random_string" "s" {
  length  = 6
  upper   = false
  special = false
}
resource "azurerm_resource_group" "rg" {
  name     = "mcscan-rg"
  location = var.location
  tags     = { project = "mcscan" }
}
# STOR-001: anonymous blob access
resource "azurerm_storage_account" "target" {
  name                            = "mcscan${random_string.s.result}"
  resource_group_name             = azurerm_resource_group.rg.name
  location                        = azurerm_resource_group.rg.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  allow_nested_items_to_be_public = var.insecure
}
resource "azurerm_storage_container" "pub" {
  name                  = "public"
  storage_account_id    = azurerm_storage_account.target.id
  container_access_type = var.insecure ? "blob" : "private"
}
# NET-001: NSG allowing SSH from the internet
resource "azurerm_network_security_group" "nsg" {
  name                = "mcscan-open-ssh"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  security_rule {
    name                       = "ssh"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "22"
    source_address_prefix      = var.insecure ? "*" : "10.0.0.0/8"
    destination_address_prefix = "*"
  }
}
# NEGATIVE CONTROL: HTTPS from the internet (must not fire NET-001)
resource "azurerm_network_security_group" "web" {
  name                = "mcscan-web-443"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  security_rule {
    name                       = "https"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
}
# IAM-001: custom role with "*" actions (defined only; assigned to nobody)
resource "azurerm_role_definition" "admin" {
  name  = "mcscan-admin-all"
  scope = "/subscriptions/${var.subscription_id}"
  permissions {
    actions = var.insecure ? ["*"] : ["Microsoft.Storage/storageAccounts/read"]
  }
  assignable_scopes = ["/subscriptions/${var.subscription_id}"]
}
