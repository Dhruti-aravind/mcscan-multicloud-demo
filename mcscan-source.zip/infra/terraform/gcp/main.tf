# GCP sandbox. insecure=true seeds misconfigurations. Requires the default VPC network.
terraform {
  required_providers {
    google = { source = "hashicorp/google" }
    random = { source = "hashicorp/random" }
  }
}
variable "project" {}
variable "region" { default = "us-central1" }
variable "insecure" {
  type    = bool
  default = true
}
provider "google" {
  project = var.project
  region  = var.region
}
resource "random_id" "s" { byte_length = 4 }
# STOR-001: bucket readable by allUsers
resource "google_storage_bucket" "target" {
  name                        = "mcscan-target-${random_id.s.hex}"
  location                    = "US"
  force_destroy               = true
  uniform_bucket_level_access = true
  public_access_prevention    = var.insecure ? "inherited" : "enforced"
}
resource "google_storage_bucket_iam_member" "public" {
  count  = var.insecure ? 1 : 0
  bucket = google_storage_bucket.target.name
  role   = "roles/storage.objectViewer"
  member = "allUsers"
}
# NET-001: firewall allowing SSH from anywhere
resource "google_compute_firewall" "ssh" {
  name          = "mcscan-open-ssh"
  network       = "default"
  source_ranges = [var.insecure ? "0.0.0.0/0" : "10.0.0.0/8"]
  allow {
    protocol = "tcp"
    ports    = ["22"]
  }
}
# NEGATIVE CONTROL: HTTPS from anywhere (must not fire NET-001)
resource "google_compute_firewall" "web" {
  name          = "mcscan-web-443"
  network       = "default"
  source_ranges = ["0.0.0.0/0"]
  allow {
    protocol = "tcp"
    ports    = ["443"]
  }
}
