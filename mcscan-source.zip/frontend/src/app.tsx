import React, { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, MotionConfig } from "motion/react";
import {
  Activity,
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronRight,
  Cloud,
  Fingerprint,
  Globe2,
  History,
  LayoutDashboard,
  LoaderCircle,
  LockKeyhole,
  LogOut,
  Menu,
  Plus,
  Search,
  Settings2,
  Shield,
  ShieldCheck,
  Terminal,
  Users,
  X,
  BookOpen,
  Boxes,
  CircleHelp,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { api, post, download, setCsrf } from "./api";
import type { Audit, Finding, Resource, Rule, Scan, User } from "./api";
import "./styles.css";

const providers = ["aws", "azure", "gcp"];
const providerNames: Record<string, string> = {
  aws: "Amazon Web Services",
  azure: "Microsoft Azure",
  gcp: "Google Cloud",
};
const shortNames: Record<string, string> = {
  aws: "AWS",
  azure: "Azure",
  gcp: "GCP",
};
const severities = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];
const nav: { id: string; label: string; icon: LucideIcon; admin?: boolean }[] =
  [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "findings", label: "Findings", icon: Shield },
    { id: "resources", label: "Resources", icon: Boxes },
    { id: "history", label: "Scan history", icon: History },
    { id: "rules", label: "Rule library", icon: BookOpen },
    { id: "clouds", label: "Cloud connections", icon: Cloud },
    { id: "users", label: "Team members", icon: Users, admin: true },
    { id: "activity", label: "Activity log", icon: Activity, admin: true },
  ];
const enter = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
  transition: { duration: 0.25 },
};
const date = (v: string | number) =>
  new Date(typeof v === "number" ? v * 1000 : v).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
const titleCase = (s: string) =>
  s.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
function Brand() {
  return (
    <span className="brand">
      <span className="brand-mark">
        <i />
        <i />
        <i />
      </span>
      mcscan<span className="brand-dot">.</span>
    </span>
  );
}
function CloudMark({
  provider,
  small = false,
}: {
  provider: string;
  small?: boolean;
}) {
  return (
    <span
      className={`cloud-mark ${provider} ${small ? "small" : ""}`}
      aria-label={shortNames[provider]}
    >
      {provider === "aws" ? (
        <span>
          aws<span className="aws-smile">⌣</span>
        </span>
      ) : provider === "azure" ? (
        <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M13 2 3 19h6l4-8 4 8h-6l-2 3h13L15 2z" />
        </svg>
      ) : (
        <svg viewBox="0 0 24 24" fill="none" strokeWidth="5" aria-hidden="true">
          <path stroke="#4285f4" d="M18 10a6 6 0 0 0-11-2" />
          <path stroke="#ea4335" d="M10 6a6 6 0 0 0-4 6" />
          <path stroke="#fbbc04" d="M6 10a5 5 0 0 0 0 10h5" />
          <path stroke="#34a853" d="M10 20h7a5 5 0 0 0 1-10" />
        </svg>
      )}
    </span>
  );
}
function Badge({ value }: { value: string }) {
  return (
    <span className={`badge ${value.toLowerCase()}`}>
      <i />
      {value.toLowerCase()}
    </span>
  );
}
function ErrorText({ error }: { error: string }) {
  return error ? (
    <div className="error" role="alert">
      {error}
    </div>
  ) : null;
}

function Mesh({ large = false }: { large?: boolean }) {
  return (
    <div className={`mesh ${large ? "large" : ""}`} aria-hidden="true">
      <svg viewBox="0 0 700 330" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="wave">
            <stop stopColor="#e4ff63" />
            <stop offset=".6" stopColor="#a3b8ff" />
            <stop offset="1" stopColor="#d380ff" />
          </linearGradient>
          <radialGradient id="glow">
            <stop stopColor="#dbff63" stopOpacity=".22" />
            <stop offset="1" stopColor="#dbff63" stopOpacity="0" />
          </radialGradient>
        </defs>
        <ellipse cx="330" cy="190" rx="260" ry="180" fill="url(#glow)" />
        {Array.from({ length: 35 }, (_, i) => (
          <motion.path
            key={i}
            d={`M ${-60 + i * 19} 350 Q ${95 + i * 16} ${-60 + Math.sin(i / 5) * 60} ${300 + i * 15} 140 T ${750 + i * 7} 100`}
            stroke="url(#wave)"
            strokeWidth=".7"
            opacity={0.15 + Math.sin(i / 12) * 0.25}
            fill="none"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.6, delay: i * 0.012 }}
          />
        ))}
        {Array.from({ length: 14 }, (_, i) => (
          <path
            key={"h" + i}
            d={`M -20 ${50 + i * 22} Q 240 ${-50 + i * 25} 400 ${140 + i * 9} T 730 ${40 + i * 25}`}
            stroke="url(#wave)"
            strokeWidth=".6"
            opacity=".17"
            fill="none"
          />
        ))}
      </svg>
      <div className="mesh-node node-a">
        <CloudMark provider="aws" small />
      </div>
      <div className="mesh-node node-b">
        <CloudMark provider="azure" small />
      </div>
      <div className="mesh-node node-c">
        <CloudMark provider="gcp" small />
      </div>
      <motion.div
        className="mesh-center"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", delay: 0.2 }}
      >
        <ShieldCheck size={30} />
      </motion.div>
    </div>
  );
}

function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const before = document.activeElement as HTMLElement;
    const el = ref.current;
    el?.querySelector<HTMLElement>("button,input,select")?.focus();
    function key(e: KeyboardEvent) {
      if (e.key === "Escape") closeRef.current();
      if (e.key === "Tab" && el) {
        const items = Array.from(
          el.querySelectorAll<HTMLElement>(
            "button:not(:disabled),input,select,a[href],textarea",
          ),
        );
        if (!items.length) return;
        const a = items[0],
          b = items.at(-1);
        if (e.shiftKey && document.activeElement === a) {
          e.preventDefault();
          b?.focus();
        } else if (!e.shiftKey && document.activeElement === b) {
          e.preventDefault();
          a.focus();
        }
      }
    }
    document.addEventListener("keydown", key);
    const old = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", key);
      document.body.style.overflow = old;
      before?.focus();
    };
  }, []);
  return (
    <motion.div
      className="modal-backdrop"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <motion.div
        ref={ref}
        className={`modal ${wide ? "wide" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        {...enter}
      >
        <div className="modal-title">
          <h2>{title}</h2>
          <button
            className="icon-button"
            aria-label="Close dialog"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>
        {children}
      </motion.div>
    </motion.div>
  );
}

function Login({ onLogin }: { onLogin: (user: User) => void }) {
  const [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [demo, setDemo] = useState(false);
  useEffect(() => {
    api<{ demo_accounts: boolean }>("/health")
      .then((r) => setDemo(r.demo_accounts))
      .catch(() => {});
  }, []);
  async function submit(e?: React.FormEvent, asDemo?: "admin" | "member") {
    e?.preventDefault();
    setError("");
    setBusy(true);
    try {
      const r = await post<{ user: User; csrf: string }>("/auth/login", {
        email: asDemo
          ? (asDemo === "admin" ? "admin" : "analyst") + "@mcscan.local"
          : email,
        password: asDemo
          ? asDemo === "admin"
            ? "Mcscan-Demo-2026!"
            : "Analyst-Demo-2026!"
          : password,
      });
      setCsrf(r.csrf);
      onLogin(r.user);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="login-page">
      <div className="login-art">
        <Brand />
        <div className="login-copy">
          <span className="eyebrow">
            <i /> MULTI-CLOUD SECURITY, IN FOCUS
          </span>
          <h1>
            Three clouds.
            <br />
            One clear view<span>.</span>
          </h1>
          <p>
            Find the gaps. Understand the risk.
            <br />
            Move forward with confidence.
          </p>
          <Mesh large />
          <div className="login-providers">
            {providers.map((p) => (
              <span key={p}>
                <CloudMark provider={p} small />
                {shortNames[p]}
              </span>
            ))}
          </div>
        </div>
        <div className="login-foot">
          READ-ONLY BY DESIGN <span>BUILT FOR CLARITY</span>
        </div>
      </div>
      <div className="login-form-wrap">
        <form onSubmit={submit} className="login-form">
          <span className="eyebrow">YOUR SECURITY WORKSPACE</span>
          <h2>Welcome back.</h2>
          <p>Sign in to see your cloud posture.</p>
          <ErrorText error={error} />
          <label>
            Email address
            <input
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
            />
          </label>
          <label>
            Password
            <input
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <button className="button primary full" disabled={busy}>
            {busy ? (
              <LoaderCircle className="spin" size={18} />
            ) : (
              <>
                Sign in <ArrowRight size={18} />
              </>
            )}
          </button>
          <div className="secure-note">
            <LockKeyhole size={13} /> Secure session · Private scan history
          </div>
          {demo && (
            <div className="demo-login">
              <div className="eyebrow">EXPLORE THE OFFLINE DEMO</div>
              <p>No cloud account needed. Real rules, synthetic resources.</p>
              <button
                type="button"
                className="button secondary full"
                disabled={busy}
                onClick={() => submit(undefined, "admin")}
              >
                Try as administrator <ArrowUpRight size={16} />
              </button>
              <button
                type="button"
                className="text-button"
                disabled={busy}
                onClick={() => submit(undefined, "member")}
              >
                Or explore as a team member <ArrowRight size={14} />
              </button>
            </div>
          )}
          <p className="contact-note">
            Need access? Ask your workspace administrator.
          </p>
        </form>
      </div>
    </div>
  );
}

function ScanModal({
  onClose,
  onScan,
}: {
  onClose: () => void;
  onScan: (s: Scan) => void;
}) {
  const [selected, setSelected] = useState(providers),
    [scenario, setScenario] = useState("baseline"),
    [criticality, setCriticality] = useState("production"),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function launch(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      onScan(
        await post<Scan>("/scans", {
          providers: selected,
          scenario,
          criticality,
          mode: "offline",
        }),
      );
    } catch (e) {
      setError((e as Error).message);
      setBusy(false);
    }
  }
  return (
    <Modal
      title="Start a new scan"
      onClose={() => {
        if (!busy) onClose();
      }}
    >
      <form onSubmit={launch}>
        <p className="muted">
          Choose your scope. Every scan runs the shared rule engine.
        </p>
        <div className="callout">
          <Terminal size={18} />
          <div>
            <strong>Offline environment</strong>
            <p>
              Synthetic fixtures for all three providers. No cloud API calls.
            </p>
          </div>
        </div>
        <label className="field-title">CLOUD PROVIDERS</label>
        <div className="provider-picker">
          {providers.map((p) => (
            <label key={p} className={selected.includes(p) ? "selected" : ""}>
              <CloudMark provider={p} />
              <span>{shortNames[p]}</span>
              <input
                type="checkbox"
                checked={selected.includes(p)}
                onChange={() =>
                  setSelected((s) =>
                    s.includes(p) ? s.filter((x) => x !== p) : [...s, p],
                  )
                }
              />
            </label>
          ))}
        </div>
        <label>
          Scenario
          <select
            value={scenario}
            onChange={(e) => setScenario(e.target.value)}
          >
            <option value="baseline">
              Baseline — seeded misconfigurations
            </option>
            <option value="hardened">Hardened — remediated fixtures</option>
          </select>
        </label>
        <label>
          Asset criticality
          <select
            value={criticality}
            onChange={(e) => setCriticality(e.target.value)}
          >
            <option value="production">Production (1.5×)</option>
            <option value="staging">Staging (1×)</option>
            <option value="dev">Development (0.5×)</option>
          </select>
        </label>
        <p className="muted small-text">
          Run baseline, then hardened with the same scope to see resolved
          findings in drift history.
        </p>
        <ErrorText error={error} />
        <button
          className="button primary full"
          disabled={busy || !selected.length}
        >
          {busy ? (
            <>
              <LoaderCircle className="spin" size={17} />
              Running rule engine…
            </>
          ) : (
            <>
              Run scan <ArrowRight size={17} />
            </>
          )}
        </button>
      </form>
    </Modal>
  );
}

function FindingsTable({
  findings,
  onSelect,
  compact = false,
}: {
  findings: Finding[];
  onSelect: (f: Finding) => void;
  compact?: boolean;
}) {
  return (
    <div className="table-scroll">
      <table className={compact ? "compact" : ""}>
        <thead>
          <tr>
            <th>Finding / resource</th>
            <th>Severity</th>
            <th>Cloud</th>
            {!compact && <th>Rule</th>}
            <th className="numeric">Risk</th>
            <th>
              <span className="sr-only">Details</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {findings.map((f) => (
            <tr key={f.provider + f.resource_id + f.rule_id}>
              <td>
                <button className="finding-title" onClick={() => onSelect(f)}>
                  {f.title}
                </button>
                <div className="resource-name">{f.resource_name}</div>
              </td>
              <td>
                <Badge value={f.severity} />
              </td>
              <td>
                <span className="provider-inline">
                  <CloudMark provider={f.provider} small />
                  {shortNames[f.provider]}
                </span>
              </td>
              {!compact && <td className="mono muted">{f.rule_id}</td>}
              <td className="numeric mono">{f.risk_score.toFixed(1)}</td>
              <td>
                <button
                  className="icon-button"
                  onClick={() => onSelect(f)}
                  aria-label={`Inspect ${f.rule_id} on ${f.resource_name}`}
                >
                  <ArrowUpRight size={16} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!findings.length && (
        <div className="empty-inline">
          <ShieldCheck size={30} />
          <strong>No findings here.</strong>
          <p>Try a different filter or scan scope.</p>
        </div>
      )}
    </div>
  );
}

function FindingDetail({
  finding: f,
  onClose,
}: {
  finding: Finding;
  onClose: () => void;
}) {
  return (
    <Modal title="Finding details" onClose={onClose} wide>
      <div className="detail-tags">
        <Badge value={f.severity} />
        <span className="tag mono">{f.rule_id}</span>
        <span className="tag">{shortNames[f.provider]}</span>
      </div>
      <h2 className="detail-heading">{f.title}</h2>
      <div className="detail-grid">
        <div>
          <label>RESOURCE</label>
          <strong>{f.resource_name}</strong>
        </div>
        <div>
          <label>RISK SCORE</label>
          <strong>{f.risk_score.toFixed(1)}</strong>
        </div>
        <div>
          <label>REGION</label>
          <strong>{f.region}</strong>
        </div>
        <div>
          <label>INTERNET EXPOSED</label>
          <strong>{f.internet_exposed ? "Yes" : "No"}</strong>
        </div>
      </div>
      <section className="remediation">
        <h3>
          <CheckCheck size={19} /> How to remediate
        </h3>
        <p>{f.remediation}</p>
      </section>
      <h3>Collected evidence</h3>
      <pre>{JSON.stringify(f.evidence, null, 2)}</pre>
      <p className="muted small-text">
        Offline fixture evidence. Remediation is guidance; this scanner does not
        modify cloud resources.
      </p>
    </Modal>
  );
}

function Overview({
  scan,
  history,
  rules,
  onNew,
  onView,
  onFinding,
}: {
  scan: Scan | null;
  history: Scan[];
  rules: Rule[];
  onNew: () => void;
  onView: (id: string) => void;
  onFinding: (f: Finding) => void;
}) {
  if (!scan)
    return (
      <motion.div {...enter}>
        <div className="welcome-hero">
          <div>
            <span className="eyebrow">VISIBILITY IS YOUR FIRST DEFENSE</span>
            <h1>
              Your clouds.
              <br />
              In the clear<span>.</span>
            </h1>
            <p>
              One rule engine. Three clouds. A clear path from
              <br className="desktop" /> misconfiguration to remediation.
            </p>
            <button className="button primary" onClick={onNew}>
              Run your first scan <ArrowRight size={17} />
            </button>
          </div>
          <Mesh />
        </div>
        <div className="section-heading">
          <h2>A good place to start.</h2>
          <span className="eyebrow">01 / YOUR WORKSPACE</span>
        </div>
        <div className="cloud-grid">
          {providers.map((p) => (
            <div className="panel cloud-card" key={p}>
              <CloudMark provider={p} />
              <h3>{providerNames[p]}</h3>
              <p>Storage, network, identity and encryption checks.</p>
              <span className="status-dot">Offline fixtures ready</span>
            </div>
          ))}
        </div>
        <div className="empty-guide panel">
          <ShieldCheck size={28} />
          <div>
            <h3>Real detection. Zero cloud setup.</h3>
            <p>
              Start with seeded issues, then scan the hardened scenario to
              measure what changed.
            </p>
          </div>
          <span className="tag">{rules.length} shared rules</span>
        </div>
      </motion.div>
    );
  const counts = scan.severity_counts;
  const critical = counts.CRITICAL || 0;
  const previous = history.find(
    (s) => s.scan_id === scan.drift.previous_scan_id,
  );
  const change = previous ? scan.account_score - previous.account_score : null;
  return (
    <motion.div {...enter}>
      <div className="page-heading">
        <div>
          <div className="eyebrow">YOUR CLOUDS, AT A GLANCE</div>
          <h1>
            Security posture<span>.</span>
          </h1>
          <p>A little visibility. A lot more confidence.</p>
        </div>
        <span className="timestamp">
          <span className="live-dot" /> Last scanned {date(scan.started_at)}
        </span>
      </div>
      <div className="stat-grid">
        <div className="stat panel risk-stat">
          <div className="stat-label">
            Overall risk{" "}
            <CircleHelp size={14}>
              <title>Higher means more detected risk; not a probability.</title>
            </CircleHelp>
          </div>
          <div className="stat-number">
            {scan.account_score.toFixed(1)}
            <span>/100</span>
            <svg className="mini-ring" viewBox="0 0 56 56">
              <circle
                cx="28"
                cy="28"
                r="23"
                fill="none"
                stroke="#30352c"
                strokeWidth="4"
              />
              <motion.circle
                cx="28"
                cy="28"
                r="23"
                fill="none"
                stroke="var(--accent)"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray="144.5"
                initial={{ strokeDashoffset: 144.5 }}
                animate={{
                  strokeDashoffset: 144.5 * (1 - scan.account_score / 100),
                }}
                transform="rotate(-90 28 28)"
              />
            </svg>
          </div>
          <div className="stat-note">
            {change !== null ? (
              <span className={change <= 0 ? "good" : "warn"}>
                {change <= 0 ? "↓" : "↑"} {Math.abs(change).toFixed(1)} since
                previous scan
              </span>
            ) : (
              "Weighted, saturating risk score"
            )}
          </div>
        </div>
        <div className="stat panel">
          <div className="stat-label">
            Open findings <Shield size={16} />
          </div>
          <div className="stat-number">
            {scan.finding_count}
            <span className="stat-pill">{critical} critical</span>
          </div>
          <div className="stat-note">
            Across {scan.providers.length} cloud providers
          </div>
        </div>
        <div className="stat panel">
          <div className="stat-label">
            Resources scanned <Boxes size={16} />
          </div>
          <div className="stat-number">
            {scan.resources_scanned}
            <span className="tiny-check">
              <Check size={15} />
            </span>
          </div>
          <div className="stat-note">
            {scan.errors.length
              ? "Partial coverage — review warnings"
              : "All selected fixtures collected"}
          </div>
        </div>
        <div className="stat panel">
          <div className="stat-label">
            Active rules <Fingerprint size={16} />
          </div>
          <div className="stat-number">
            {rules.length}
            <span className="sub-number">/ {rules.length}</span>
          </div>
          <div className="stat-note">
            {new Set(rules.map((r) => r.id.split("-")[0])).size} security
            categories
          </div>
        </div>
      </div>
      <div className="posture-grid">
        <div className="panel posture-card">
          <div className="panel-heading">
            <h2>Finding distribution</h2>
            <span className="eyebrow">BY SEVERITY</span>
          </div>
          <div className="severity-chart">
            <div className="severity-total">
              <strong>{scan.finding_count}</strong>
              <span>open findings</span>
            </div>
            <div className="severity-bars">
              {severities.map((s) => (
                <div className="severity-row" key={s}>
                  <span>
                    <i className={s.toLowerCase()} />
                    {titleCase(s.toLowerCase())}
                  </span>
                  <div className="bar-track">
                    <motion.div
                      className={s.toLowerCase()}
                      initial={{ width: 0 }}
                      animate={{
                        width: `${((counts[s] || 0) / Math.max(scan.finding_count, 1)) * 100}%`,
                      }}
                    />
                  </div>
                  <strong className="mono">{counts[s] || 0}</strong>
                </div>
              ))}
            </div>
          </div>
          <div className="panel-foot">
            <ShieldCheck size={14} /> Prioritize internet-exposed resources
            first.
          </div>
        </div>
        <div className="signal-card panel">
          <div className="signal-copy">
            <span className="eyebrow">THREE CLOUDS. ONE STANDARD.</span>
            <h2>
              Less noise.
              <br />
              More signal<span>.</span>
            </h2>
            <p>
              The same rules.
              <br />A shared language for risk.
            </p>
          </div>
          <Mesh />
        </div>
      </div>
      <div className="section-heading">
        <h2>
          Cloud coverage <span className="count">{scan.providers.length}</span>
        </h2>
        <button className="text-button" onClick={() => onView("clouds")}>
          View connections <ArrowUpRight size={15} />
        </button>
      </div>
      <div className="cloud-grid">
        {scan.providers.map((p, i) => {
          const resources = scan.resources.filter(
              (r) => r.provider === p,
            ).length,
            findings = scan.findings.filter((f) => f.provider === p).length;
          return (
            <motion.button
              whileHover={{ y: -3 }}
              className="panel cloud-summary"
              key={p}
              onClick={() => onView("findings:" + p)}
            >
              <div className="cloud-title">
                <CloudMark provider={p} />
                <div>
                  <h3>{providerNames[p]}</h3>
                  <span>OFFLINE / {String(i + 1).padStart(2, "0")}</span>
                </div>
                <ArrowUpRight size={16} />
              </div>
              <div className="cloud-stats">
                <div>
                  <strong>{resources}</strong>
                  <span>resources</span>
                </div>
                <div>
                  <strong>{findings}</strong>
                  <span>findings</span>
                </div>
                <div>
                  <strong className={findings ? "accent" : "good"}>
                    {scan.score_by_provider[p]}
                  </strong>
                  <span>risk score</span>
                </div>
              </div>
              <div className="cloud-track">
                <div style={{ width: `${scan.score_by_provider[p]}%` }} />
              </div>
            </motion.button>
          );
        })}
      </div>
      <div className="bottom-grid">
        <div className="panel">
          <div className="panel-heading">
            <h2>Needs your attention</h2>
            <button className="text-button" onClick={() => onView("findings")}>
              All findings <ArrowUpRight size={15} />
            </button>
          </div>
          <FindingsTable
            compact
            findings={scan.findings.slice(0, 4)}
            onSelect={onFinding}
          />
        </div>
        <div className="panel recent-panel">
          <div className="panel-heading">
            <h2>Recent scans</h2>
            <History size={16} />
          </div>
          {history.slice(0, 4).map((s) => (
            <button
              key={s.scan_id}
              className="recent-scan"
              onClick={() => onView("scan:" + s.scan_id)}
            >
              <span className="timeline-icon">
                <Check size={15} />
              </span>
              <span>
                <strong>{titleCase(s.scenario)} scan</strong>
                <small>
                  {date(s.started_at)} · {s.providers.length} clouds
                </small>
              </span>
              <span className="mono">{s.account_score}</span>
            </button>
          ))}
          <button
            className="text-button history-link"
            onClick={() => onView("history")}
          >
            View scan history <ArrowRight size={15} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function FindingsView({
  scan,
  initialProvider,
  onFinding,
}: {
  scan: Scan | null;
  initialProvider: string;
  onFinding: (f: Finding) => void;
}) {
  const [query, setQuery] = useState(""),
    [provider, setProvider] = useState(initialProvider),
    [severity, setSeverity] = useState("all");
  const findings = (scan?.findings || []).filter(
    (f) =>
      (provider === "all" || f.provider === provider) &&
      (severity === "all" || f.severity === severity) &&
      `${f.title} ${f.resource_name} ${f.rule_id}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  return (
    <>
      <PageTitle
        eyebrow="UNDERSTAND WHAT MATTERS"
        title="Findings"
        text="Evidence and a clear next step for every detected issue."
      />
      <div className="filters">
        <div className="search-field">
          <Search size={16} />
          <input
            aria-label="Search findings"
            placeholder="Search findings, resources or rules…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <select
          aria-label="Filter cloud"
          value={provider}
          onChange={(e) => setProvider(e.target.value)}
        >
          <option value="all">All clouds</option>
          {providers.map((p) => (
            <option key={p} value={p}>
              {shortNames[p]}
            </option>
          ))}
        </select>
        <select
          aria-label="Filter severity"
          value={severity}
          onChange={(e) => setSeverity(e.target.value)}
        >
          <option value="all">All severities</option>
          {severities.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>
      <div className="panel">
        <div className="panel-heading">
          <h2>
            Detected issues <span className="count">{findings.length}</span>
          </h2>
          <span className="muted small-text">Sorted by weighted risk</span>
        </div>
        <FindingsTable findings={findings} onSelect={onFinding} />
      </div>
    </>
  );
}
function PageTitle({
  eyebrow,
  title,
  text,
}: {
  eyebrow: string;
  title: string;
  text: string;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>
          {title}
          <span>.</span>
        </h1>
        <p>{text}</p>
      </div>
    </div>
  );
}

function ResourcesView({ scan }: { scan: Scan | null }) {
  const [query, setQuery] = useState(""),
    [provider, setProvider] = useState("all"),
    [resource, setResource] = useState<Resource | null>(null);
  const resources = (scan?.resources || []).filter(
    (r) =>
      (provider === "all" || r.provider === provider) &&
      `${r.name} ${r.resource_type} ${r.region}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  return (
    <>
      <PageTitle
        eyebrow="KNOW YOUR SURFACE"
        title="Resource inventory"
        text="Normalized assets from your selected scan, in one place."
      />
      <div className="filters">
        <div className="search-field">
          <Search size={16} />
          <input
            aria-label="Search resources"
            placeholder="Search by name, type or region…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <select
          aria-label="Filter resources by cloud"
          value={provider}
          onChange={(e) => setProvider(e.target.value)}
        >
          <option value="all">All clouds</option>
          {providers.map((p) => (
            <option key={p} value={p}>
              {shortNames[p]}
            </option>
          ))}
        </select>
      </div>
      <div className="panel table-scroll">
        <table>
          <thead>
            <tr>
              <th>Resource</th>
              <th>Type</th>
              <th>Cloud</th>
              <th>Region</th>
              <th>Findings</th>
            </tr>
          </thead>
          <tbody>
            {resources.map((r) => {
              const count = scan?.findings.filter(
                (f) =>
                  f.resource_id === r.resource_id && f.provider === r.provider,
              ).length;
              return (
                <tr key={r.resource_id}>
                  <td>
                    <button
                      className="finding-title"
                      onClick={() => setResource(r)}
                    >
                      {r.name}
                    </button>
                  </td>
                  <td className="muted">{titleCase(r.resource_type)}</td>
                  <td>
                    <span className="provider-inline">
                      <CloudMark provider={r.provider} small />
                      {shortNames[r.provider]}
                    </span>
                  </td>
                  <td className="mono muted">{r.region}</td>
                  <td>
                    <span className={count ? "warn" : "good"}>
                      {count || 0} {count ? "open" : "· clean"}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!resources.length && (
          <div className="empty-inline">
            No resources match this view. Run a scan to populate your inventory.
          </div>
        )}
      </div>
      {resource && (
        <Modal title={resource.name} onClose={() => setResource(null)}>
          <span className="tag">
            {shortNames[resource.provider]} /{" "}
            {titleCase(resource.resource_type)}
          </span>
          <h3>Normalized properties</h3>
          <pre>{JSON.stringify(resource.properties, null, 2)}</pre>
          <p className="mono muted small-text">{resource.resource_id}</p>
        </Modal>
      )}
    </>
  );
}

function RulesView({ rules }: { rules: Rule[] }) {
  const [selected, setSelected] = useState<Rule | null>(null);
  return (
    <>
      <PageTitle
        eyebrow="ONE ENGINE, SHARED STANDARDS"
        title="Rule library"
        text="Eight transparent YAML rules. Four security categories. No black box."
      />
      <div className="callout">
        <BookOpen size={20} />
        <div>
          <strong>Coverage has boundaries.</strong>
          <p>
            Database checks are AWS-only. Azure and GCP disks are encrypted by
            default; ENC-001 can fire on AWS. These fixtures do not establish
            live-cloud accuracy.
          </p>
        </div>
      </div>
      <div className="rule-grid">
        {rules.map((r) => (
          <motion.button
            whileHover={{ y: -3 }}
            className="panel rule-card"
            key={r.id}
            onClick={() => setSelected(r)}
          >
            <div>
              <span className="eyebrow">{r.id}</span>
              <Badge value={r.severity} />
            </div>
            <h3>{r.title}</h3>
            <div className="rule-foot">
              <span>{r.coverage}</span>
              <ArrowUpRight size={17} />
            </div>
          </motion.button>
        ))}
      </div>
      {selected && (
        <Modal title={selected.id} onClose={() => setSelected(null)} wide>
          <Badge value={selected.severity} />
          <h2>{selected.title}</h2>
          <p className="muted">
            {selected.coverage} · {selected.tests} embedded test cases
          </p>
          <h3>Detection condition</h3>
          <pre>{selected.condition}</pre>
          <h3>Remediation guidance</h3>
          {Object.entries(selected.remediation).map(([p, t]) => (
            <div className="rule-remediation" key={p}>
              <span className="tag">
                {p === "default" ? "All providers" : shortNames[p]}
              </span>
              <p>{t}</p>
            </div>
          ))}
        </Modal>
      )}
    </>
  );
}

function HistoryView({
  history,
  onOpen,
}: {
  history: Scan[];
  onOpen: (id: string) => void;
}) {
  return (
    <>
      <PageTitle
        eyebrow="PROGRESS, MADE VISIBLE"
        title="Scan history"
        text="Compare equivalent scopes and see new and resolved findings."
      />
      <div className="panel table-scroll">
        <table>
          <thead>
            <tr>
              <th>Scan</th>
              <th>Scope</th>
              <th>Risk</th>
              <th>Findings</th>
              <th>Drift</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {history.map((s) => (
              <tr key={s.scan_id}>
                <td>
                  <button
                    className="finding-title"
                    onClick={() => onOpen(s.scan_id)}
                  >
                    {titleCase(s.scenario)} · {titleCase(s.criticality)}
                  </button>
                  <div className="resource-name">
                    {date(s.started_at)} · {s.scan_id.slice(0, 8)}
                  </div>
                </td>
                <td>
                  <div className="provider-stack">
                    {s.providers.map((p) => (
                      <CloudMark key={p} provider={p} small />
                    ))}
                  </div>
                </td>
                <td className="mono">{s.account_score}</td>
                <td className="mono">{s.finding_count}</td>
                <td>
                  {s.drift.previous_scan_id ? (
                    <div className="drift-count">
                      <span className="warn">+{s.drift.new.length} new</span>
                      <span className="good">
                        −{s.drift.resolved.length} resolved
                      </span>
                    </div>
                  ) : (
                    <span className="muted small-text">First in scope</span>
                  )}
                </td>
                <td>
                  <button
                    className="icon-button"
                    aria-label={`Open scan ${s.scan_id}`}
                    onClick={() => onOpen(s.scan_id)}
                  >
                    <ArrowUpRight size={17} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!history.length && (
          <div className="empty-inline">
            Your scan history starts with your first scan.
          </div>
        )}
      </div>
      <div className="callout">
        <History size={19} />
        <p>
          Drift compares your most recent scan with the same providers and
          criticality. Account and resource identities are included, so findings
          from different clouds stay distinct.
        </p>
      </div>
    </>
  );
}

function CloudsView({ onScan }: { onScan: () => void }) {
  return (
    <>
      <PageTitle
        eyebrow="YOUR CLOUD LANDSCAPE"
        title="Cloud connections"
        text="Explore all three providers offline. Connect real accounts in the next phase."
      />
      <div className="cloud-grid">
        {providers.map((p) => (
          <div className="panel connection-card" key={p}>
            <div className="connection-top">
              <CloudMark provider={p} />
              <span className="tag">OFFLINE</span>
            </div>
            <h2>{providerNames[p]}</h2>
            <p>
              Synthetic storage, firewall, identity and disk resources, using a
              shared normalized schema.
            </p>
            <div className="connection-row">
              <span>Fixture source</span>
              <span className="good">
                <Check size={14} /> Available
              </span>
            </div>
            <div className="connection-row">
              <span>Cloud API access</span>
              <span className="muted">Not connected</span>
            </div>
            <button className="button secondary full" onClick={onScan}>
              Scan offline fixtures <ArrowRight size={16} />
            </button>
          </div>
        ))}
      </div>
      <div className="panel live-info">
        <div className="tag">NEXT PHASE</div>
        <h2>Ready for real-world validation.</h2>
        <p>
          The original read-only collectors and Terraform sandboxes are
          included. The CLI can use configured cloud identities when you're
          ready. This web release keeps live access disabled until individual
          user identities and account authorization are configured.
        </p>
        <div className="code-line">
          <Terminal size={15} />
          <code>
            mcscan scan --provider aws --region us-east-1 --format cli json html
          </code>
        </div>
      </div>
    </>
  );
}

function MembersView({ notify }: { notify: (s: string) => void }) {
  const [users, setUsers] = useState<User[]>([]),
    [show, setShow] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [form, setForm] = useState({ name: "", email: "", password: "" });
  async function load() {
    try {
      setUsers(await api<User[]>("/users"));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  useEffect(() => {
    void load();
  }, []);
  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await post("/users", form);
      await load();
      setShow(false);
      setForm({ name: "", email: "", password: "" });
      notify("Team member created");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function toggle(u: User) {
    try {
      await api("/users/" + u.id, {
        method: "PATCH",
        body: JSON.stringify({ active: !u.active }),
      });
      await load();
      notify(
        u.active
          ? "Member deactivated. Sessions revoked."
          : "Member reactivated.",
      );
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <>
      <div className="split-title">
        <PageTitle
          eyebrow="ONE ADMIN. A SHARED MISSION."
          title="Team members"
          text="Manage access. Every member has a private scan workspace."
        />
        <button
          className="button primary"
          onClick={() => {
            setError("");
            setShow(true);
          }}
        >
          <Plus size={17} />
          Add member
        </button>
      </div>
      <ErrorText error={show ? "" : error} />
      <div className="panel table-scroll">
        <table>
          <thead>
            <tr>
              <th>Member</th>
              <th>Role</th>
              <th>Status</th>
              <th>Scans</th>
              <th>Access</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>
                  <div className="member-name">
                    <span className="avatar">
                      {u.name
                        .split(" ")
                        .map((s) => s[0])
                        .slice(0, 2)
                        .join("")}
                    </span>
                    <div>
                      <strong>{u.name}</strong>
                      <div className="resource-name">{u.email}</div>
                    </div>
                  </div>
                </td>
                <td>
                  <span
                    className={`tag ${u.role === "admin" ? "accent-tag" : ""}`}
                  >
                    {u.role === "admin" ? "Administrator" : "Member"}
                  </span>
                </td>
                <td>
                  <span className={u.active ? "status-dot" : "muted"}>
                    {u.active ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="mono">{u.scan_count}</td>
                <td>
                  {u.role === "admin" ? (
                    <span className="muted small-text">Single admin</span>
                  ) : (
                    <button
                      className="button small secondary"
                      onClick={() => toggle(u)}
                    >
                      {u.active ? "Deactivate" : "Reactivate"}
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="muted small-text">
        Deactivating a member ends their active sessions and preserves their
        scans. Members cannot manage accounts or view other members’ scans.
      </p>
      {show && (
        <Modal title="Add a team member" onClose={() => setShow(false)}>
          <form onSubmit={create}>
            <p className="muted">
              Create a member account and share the initial credentials
              directly. Members can change their password in Settings.
            </p>
            {(["name", "email", "password"] as const).map((k) => (
              <label key={k}>
                {k === "name"
                  ? "Full name"
                  : k === "email"
                    ? "Email address"
                    : "Initial password"}
                <input
                  required
                  type={
                    k === "password"
                      ? "password"
                      : k === "email"
                        ? "email"
                        : "text"
                  }
                  minLength={k === "password" ? 12 : 1}
                  maxLength={k === "name" ? 80 : k === "email" ? 254 : 256}
                  autoComplete="off"
                  value={form[k]}
                  onChange={(e) => setForm({ ...form, [k]: e.target.value })}
                />
              </label>
            ))}
            <ErrorText error={error} />
            <button className="button primary full" disabled={busy}>
              {busy ? "Creating…" : "Create member"}
              <ArrowRight size={16} />
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}
function AuditView() {
  const [items, setItems] = useState<Audit[]>([]),
    [error, setError] = useState("");
  useEffect(() => {
    api<Audit[]>("/audit")
      .then(setItems)
      .catch((e) => setError(e.message));
  }, []);
  return (
    <>
      <PageTitle
        eyebrow="ACCOUNTABILITY, BUILT IN"
        title="Activity log"
        text="Workspace sign-ins, membership changes, scans and exports."
      />
      <ErrorText error={error} />
      <div className="panel">
        <div className="audit-list">
          {items.map((a) => (
            <div key={a.id}>
              <span className="timeline-icon">
                <Activity size={16} />
              </span>
              <div>
                <strong>{titleCase(a.action)}</strong>
                <p>
                  {a.user_name || "Unknown member"}{" "}
                  <span className="mono">{a.detail}</span>
                </p>
              </div>
              <time>{date(a.created_at)}</time>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
function SettingsView({
  user,
  onLogout,
}: {
  user: User;
  onLogout: () => void;
}) {
  const [current, setCurrent] = useState(""),
    [password, setPassword] = useState(""),
    [confirm, setConfirm] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  async function change(e: React.FormEvent) {
    e.preventDefault();
    if (password !== confirm) {
      setError("New passwords must match");
      return;
    }
    setBusy(true);
    try {
      await post("/auth/password", {
        current_password: current,
        new_password: password,
      });
      onLogout();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="MAKE IT YOURS"
        title="Account settings"
        text="Your profile and session security."
      />
      <div className="settings-grid">
        <div className="panel settings-panel">
          <h2>Profile</h2>
          <div className="detail-grid">
            <div>
              <label>NAME</label>
              <strong>{user.name}</strong>
            </div>
            <div>
              <label>ROLE</label>
              <strong>{titleCase(user.role)}</strong>
            </div>
            <div>
              <label>EMAIL</label>
              <strong>{user.email}</strong>
            </div>
          </div>
          <div className="callout">
            <LockKeyhole size={18} />
            <p>
              Your session expires after 12 hours. Scan data is private to your
              account.
            </p>
          </div>
        </div>
        <form className="panel settings-panel" onSubmit={change}>
          <h2>Change password</h2>
          <p className="muted small-text">
            Changing your password signs you out of all sessions.
          </p>
          <label>
            Current password
            <input
              required
              type="password"
              autoComplete="current-password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
            />
          </label>
          <label>
            New password
            <input
              required
              type="password"
              minLength={12}
              maxLength={256}
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <label>
            Confirm new password
            <input
              required
              type="password"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          </label>
          <ErrorText error={error} />
          <button className="button primary" disabled={busy}>
            Update password <ArrowRight size={16} />
          </button>
        </form>
      </div>
    </>
  );
}

export function App() {
  const [user, setUser] = useState<User | null>(null),
    [loading, setLoading] = useState(true),
    [view, setView] = useState("overview"),
    [scan, setScan] = useState<Scan | null>(null),
    [history, setHistory] = useState<Scan[]>([]),
    [rules, setRules] = useState<Rule[]>([]),
    [scanModal, setScanModal] = useState(false),
    [finding, setFinding] = useState<Finding | null>(null),
    [exportOpen, setExportOpen] = useState(false),
    [notice, setNotice] = useState(""),
    [error, setError] = useState(""),
    [mobile, setMobile] = useState(false),
    [initialProvider, setInitialProvider] = useState("all");
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  function notify(s: string) {
    setNotice(s);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setNotice(""), 4500);
  }
  function clearSession() {
    setUser(null);
    setScan(null);
    setHistory([]);
    setRules([]);
    setCsrf("");
    setView("overview");
  }
  useEffect(() => {
    api<{ user: User; csrf: string }>("/auth/me")
      .then((r) => {
        setCsrf(r.csrf);
        setUser(r.user);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
    const expired = () => {
      clearSession();
      setError("Your session ended. Sign in again.");
    };
    window.addEventListener("session-expired", expired);
    return () => {
      window.removeEventListener("session-expired", expired);
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);
  useEffect(() => {
    if (!user) return;
    let active = true;
    Promise.all([api<Scan[]>("/scans"), api<Rule[]>("/rules")])
      .then(async ([h, r]) => {
        if (!active) return;
        setHistory(h);
        setRules(r);
        if (h.length) {
          const result = await api<Scan>("/scans/" + h[0].scan_id);
          if (active) setScan(result);
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      });
    return () => {
      active = false;
    };
  }, [user]);
  async function navigate(id: string) {
    setMobile(false);
    setError("");
    if (id.startsWith("scan:")) {
      try {
        setScan(await api<Scan>("/scans/" + id.slice(5)));
        setView("overview");
        notify("Viewing selected scan");
      } catch (e) {
        setError((e as Error).message);
      }
      return;
    }
    if (id.startsWith("findings:")) {
      setInitialProvider(id.split(":")[1]);
      setView("findings");
    } else {
      setInitialProvider("all");
      setView(id);
    }
  }
  async function logout() {
    try {
      await post("/auth/logout");
      clearSession();
    } catch (e) {
      setError((e as Error).message);
    }
  }
  function completed(s: Scan) {
    setScan(s);
    setHistory((h) => [s, ...h]);
    setScanModal(false);
    setView("overview");
    notify(
      `Scan complete · ${s.resources_scanned} resources · ${s.finding_count} findings`,
    );
  }
  async function exportReport(kind: string) {
    setExportOpen(false);
    if (!scan) return;
    try {
      await download(scan, kind);
      notify(`${kind.toUpperCase()} report downloaded`);
    } catch (e) {
      setError((e as Error).message);
    }
  }
  if (loading)
    return (
      <div className="loading-screen">
        <Brand />
        <LoaderCircle className="spin" />
      </div>
    );
  if (!user)
    return (
      <MotionConfig reducedMotion="user">
        <Login
          onLogin={(u) => {
            setError("");
            setUser(u);
          }}
        />
      </MotionConfig>
    );
  const activeNav = nav.find((n) => n.id === view)?.label || "Settings";
  return (
    <MotionConfig reducedMotion="user">
      <div className="app">
        <a href="#main-content" className="skip-link">
          Skip to content
        </a>
        {mobile && (
          <div className="mobile-scrim" onClick={() => setMobile(false)} />
        )}
        <aside className={`sidebar ${mobile ? "open" : ""}`}>
          <div className="sidebar-brand">
            <Brand />
            <span className="version">v1.0</span>
          </div>
          <button
            className="workspace-switch"
            onClick={() => navigate("settings")}
          >
            <span className="workspace-icon">
              <ShieldCheck size={18} />
            </span>
            <span>
              <strong>Security workspace</strong>
              <small>
                {user.role === "admin" ? "Administrator" : "Team member"}
              </small>
            </span>
            <ChevronRight size={14} />
          </button>
          <div className="nav-label">WORKSPACE</div>
          <nav>
            {nav
              .filter((n) => !n.admin || user.role === "admin")
              .map((n) => (
                <button
                  key={n.id}
                  onClick={() => navigate(n.id)}
                  className={view === n.id ? "active" : ""}
                >
                  {view === n.id && (
                    <motion.span
                      layoutId="nav-indicator"
                      className="nav-indicator"
                    />
                  )}
                  <n.icon size={17} />
                  <span>{n.label}</span>
                  {n.id === "findings" && !!scan?.finding_count && (
                    <small>{scan.finding_count}</small>
                  )}
                </button>
              ))}
          </nav>
          <div className="sidebar-bottom">
            <div className="offline-box">
              <span className="status-dot">Offline demo</span>
              <p>
                All the signal.
                <br />
                No cloud account required.
              </p>
              <button onClick={() => navigate("clouds")}>
                Explore environments <ArrowUpRight size={13} />
              </button>
            </div>
            <button
              className={
                view === "settings" ? "bottom-nav active" : "bottom-nav"
              }
              onClick={() => navigate("settings")}
            >
              <Settings2 size={17} />
              Settings
            </button>
            <button className="user-profile" onClick={logout} title="Sign out">
              <span className="avatar">
                {user.name
                  .split(" ")
                  .map((s) => s[0])
                  .slice(0, 2)
                  .join("")}
              </span>
              <span>
                <strong>{user.name}</strong>
                <small>
                  {user.role === "admin" ? "Administrator" : "Member"}
                </small>
              </span>
              <LogOut size={16} />
            </button>
          </div>
        </aside>
        <div className="main-wrap">
          <header className="topbar">
            <div className="breadcrumb">
              <button
                className="icon-button mobile-menu"
                aria-label="Open navigation"
                onClick={() => setMobile(true)}
              >
                <Menu size={20} />
              </button>
              <ShieldCheck size={16} />
              <span>Workspace</span>
              <ChevronRight size={13} />
              <strong>{activeNav}</strong>
            </div>
            <div className="topbar-right">
              <span className="offline-indicator">
                <i /> OFFLINE ENVIRONMENT
              </span>
              <button
                className="icon-button"
                aria-label="View account settings"
                onClick={() => navigate("settings")}
              >
                <span className="avatar tiny">{user.name[0]}</span>
              </button>
            </div>
          </header>
          <div className="toolbar">
            <span className="scope-label">
              <Globe2 size={14} />
              {scan
                ? `${scan.providers.length} clouds / ${titleCase(scan.criticality)} / ${titleCase(scan.scenario)}`
                : "Multi-cloud security"}
            </span>
            <div className="toolbar-actions">
              {scan && (
                <div className="export-wrap">
                  <button
                    className="button secondary small"
                    onClick={() => setExportOpen(!exportOpen)}
                    aria-expanded={exportOpen}
                  >
                    <ArrowDownToLine size={14} /> Export report{" "}
                    <ChevronDown size={13} />
                  </button>
                  {exportOpen && (
                    <>
                      <div
                        className="dropdown-catcher"
                        onClick={() => setExportOpen(false)}
                      />
                      <div className="dropdown">
                        {["html", "json", "sarif", "csv"].map((k) => (
                          <button key={k} onClick={() => exportReport(k)}>
                            {k.toUpperCase()} report{" "}
                            <ArrowDownToLine size={14} />
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}
              <motion.button
                whileTap={{ scale: 0.97 }}
                className="button primary small"
                onClick={() => setScanModal(true)}
              >
                <Plus size={16} />
                New scan
              </motion.button>
            </div>
          </div>
          <main id="main-content">
            <ErrorText error={error} />
            <AnimatePresence mode="wait">
              <motion.div
                key={view + (view === "findings" ? initialProvider : "")}
                {...enter}
              >
                {view === "overview" && (
                  <Overview
                    scan={scan}
                    history={history}
                    rules={rules}
                    onNew={() => setScanModal(true)}
                    onView={navigate}
                    onFinding={setFinding}
                  />
                )}{" "}
                {view === "findings" && (
                  <FindingsView
                    scan={scan}
                    initialProvider={initialProvider}
                    onFinding={setFinding}
                  />
                )}{" "}
                {view === "resources" && <ResourcesView scan={scan} />}{" "}
                {view === "history" && (
                  <HistoryView
                    history={history}
                    onOpen={(id) => navigate("scan:" + id)}
                  />
                )}{" "}
                {view === "rules" && <RulesView rules={rules} />}{" "}
                {view === "clouds" && (
                  <CloudsView onScan={() => setScanModal(true)} />
                )}{" "}
                {view === "users" && user.role === "admin" && (
                  <MembersView notify={notify} />
                )}{" "}
                {view === "activity" && user.role === "admin" && <AuditView />}{" "}
                {view === "settings" && (
                  <SettingsView
                    user={user}
                    onLogout={() => {
                      clearSession();
                      notify(
                        "Password changed. Sign in with your new password.",
                      );
                    }}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </main>
          <footer className="app-footer">
            <span>
              <span className="footer-mark">///</span> Visibility is your first
              defense.
            </span>
            <span>READ-ONLY · FIXTURE-VALIDATED · v1.0.0</span>
          </footer>
        </div>
        <AnimatePresence>
          {scanModal && (
            <ScanModal onClose={() => setScanModal(false)} onScan={completed} />
          )}{" "}
          {finding && (
            <FindingDetail finding={finding} onClose={() => setFinding(null)} />
          )}{" "}
          {notice && (
            <motion.div
              className="toast"
              role="status"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
            >
              <Check size={17} />
              {notice}
              <button
                aria-label="Dismiss notification"
                onClick={() => setNotice("")}
              >
                <X size={15} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}

