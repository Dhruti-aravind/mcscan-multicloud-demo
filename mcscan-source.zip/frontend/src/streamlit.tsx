import { createRoot, type Root } from "react-dom/client";
import { App } from "./app";
import { setStreamlitBridge } from "./api";

type RequestMessage = {
  id: number;
  path: string;
  method: string;
  body: string | null;
  csrf: string;
};
type Reply = {
  id: number;
  status: number;
  body?: unknown;
  content?: string;
  mime?: string;
  error?: string;
};
type ComponentArgs = {
  parentElement: HTMLElement | ShadowRoot;
  data: { reply?: Reply | null };
  setTriggerValue: (key: string, value: RequestMessage) => void;
};
type Queued = {
  message: RequestMessage;
  resolve: (value: unknown) => void;
  reject: (reason: Error) => void;
};
type State = {
  root: Root;
  queue: Queued[];
  active: Queued | null;
  lastReplyId: number;
  send: ComponentArgs["setTriggerValue"];
};

const roots = new WeakMap<ComponentArgs["parentElement"], State>();
let nextId = 0;

function pump(state: State) {
  if (!state.active && state.queue.length) {
    state.active = state.queue.shift()!;
    state.send("request", state.active.message);
  }
}

export default function render(args: ComponentArgs) {
  let state = roots.get(args.parentElement);
  if (!state) {
    const element = args.parentElement.querySelector(".react-root");
    if (!element) throw new Error("Streamlit dashboard root was not mounted");
    state = {
      root: createRoot(element),
      queue: [],
      active: null,
      lastReplyId: 0,
      send: args.setTriggerValue,
    };
    roots.set(args.parentElement, state);
  }
  state.send = args.setTriggerValue;
  const reply = args.data?.reply;
  if (reply && reply.id !== state.lastReplyId && state.active?.message.id === reply.id) {
    state.lastReplyId = reply.id;
    const completed = state.active;
    state.active = null;
    if (reply.status >= 200 && reply.status < 300)
      completed.resolve(reply.content !== undefined ? reply : reply.body);
    else completed.reject(new Error(reply.error || "Request failed"));
    pump(state);
  }

  const current = state;
  setStreamlitBridge((path, options) => new Promise((resolve, reject) => {
    const headers = options.headers as Record<string, string> | undefined;
    current.queue.push({
      message: {
        id: ++nextId,
        path,
        method: options.method || "GET",
        body: typeof options.body === "string" ? options.body : null,
        csrf: headers?.["X-CSRF-Token"] || "",
      },
      resolve,
      reject,
    });
    pump(current);
  }));
  state.root.render(<App />);

  return () => {
    const mounted = roots.get(args.parentElement);
    if (mounted) {
      mounted.root.unmount();
      roots.delete(args.parentElement);
      setStreamlitBridge(null);
    }
  };
}
