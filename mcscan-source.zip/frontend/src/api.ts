export type User = {
  id: string;
  email: string;
  name: string;
  role: "admin" | "member";
  active: boolean;
  created_at: number;
  scan_count?: number;
};
export type Finding = {
  rule_id: string;
  title: string;
  severity: string;
  provider: string;
  resource_type: string;
  resource_id: string;
  resource_name: string;
  region: string;
  account_id: string;
  risk_score: number;
  internet_exposed: boolean;
  remediation: string;
  evidence: Record<string, unknown>;
  compliance: Record<string, string[]>;
};
export type Resource = {
  provider: string;
  resource_type: string;
  resource_id: string;
  name: string;
  region: string;
  account_id: string;
  properties: Record<string, unknown>;
  tags: Record<string, string>;
};
export type Scan = {
  scan_id: string;
  started_at: string;
  duration_s: number;
  criticality: string;
  providers: string[];
  resources_scanned: number;
  account_score: number;
  score_by_provider: Record<string, number>;
  mode: string;
  scenario: string;
  status: string;
  findings: Finding[];
  resources: Resource[];
  severity_counts: Record<string, number>;
  finding_count: number;
  errors: string[];
  drift: {
    previous_scan_id: string | null;
    new: string[];
    resolved: string[];
    unchanged: number;
  };
};
export type Rule = {
  id: string;
  title: string;
  severity: string;
  resource_type: string;
  providers: string[];
  condition: string;
  remediation: Record<string, string>;
  tests: number;
  coverage: string;
};
export type Audit = {
  id: number;
  user_name: string;
  action: string;
  detail: string;
  created_at: number;
};
let csrf = "";
type Bridge = (path: string, options: RequestInit) => Promise<any>;
let bridge: Bridge | null = null;
export function setStreamlitBridge(value: Bridge | null) {
  bridge = value;
}
export function setCsrf(value: string) {
  csrf = value;
}
export async function api<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  if (bridge) {
    try {
      return (await bridge(path, {
        ...options,
        headers: { "X-CSRF-Token": csrf, ...options.headers },
      })) as T;
    } catch (error) {
      if (String(error).includes("Sign in to continue") && path !== "/auth/me")
        window.dispatchEvent(new Event("session-expired"));
      throw error;
    }
  }
  const response = await fetch("/api" + path, {
    credentials: "same-origin",
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": csrf,
      ...options.headers,
    },
  });
  if (!response.ok) {
    const body = await response
      .json()
      .catch(() => ({ detail: "The server could not complete this request" }));
    const message =
      typeof body.detail === "string"
        ? body.detail
        : body.detail?.map((x: { msg: string }) => x.msg).join("; ");
    if (
      response.status === 401 &&
      path !== "/auth/login" &&
      path !== "/auth/me"
    )
      window.dispatchEvent(new Event("session-expired"));
    throw new Error(message || "Request failed");
  }
  return response.json();
}
export function post<T>(path: string, body: unknown = {}) {
  return api<T>(path, { method: "POST", body: JSON.stringify(body) });
}
export async function download(scan: Scan, kind: string) {
  if (bridge) {
    const result = await bridge(`/scans/${scan.scan_id}/export/${kind}`, {});
    const url = URL.createObjectURL(new Blob([result.content], { type: result.mime }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `mcscan-${scan.scan_id}.${kind}`;
    a.click();
    URL.revokeObjectURL(url);
    return;
  }
  const response = await fetch(`/api/scans/${scan.scan_id}/export/${kind}`, {
    credentials: "same-origin",
  });
  if (!response.ok)
    throw new Error("Report download failed. Sign in and try again.");
  const url = URL.createObjectURL(await response.blob());
  const a = document.createElement("a");
  a.href = url;
  a.download = `mcscan-${scan.scan_id}.${kind}`;
  a.click();
  URL.revokeObjectURL(url);
}
