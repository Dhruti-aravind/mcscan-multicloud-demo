import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  define: { "process.env.NODE_ENV": JSON.stringify("production") },
  build: {
    outDir: "../src/mcscan/streamlit_component/assets",
    emptyOutDir: true,
    lib: { entry: "src/streamlit.tsx", formats: ["es"], fileName: () => "streamlit.js" },
    cssCodeSplit: false,
    rollupOptions: { output: { assetFileNames: "streamlit.css" } },
  },
});
