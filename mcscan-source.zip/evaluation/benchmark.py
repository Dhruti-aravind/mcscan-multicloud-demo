"""Usage: python evaluation/benchmark.py reports/<scan>.json evaluation/ground_truth.yaml"""
import json
import sys
from pathlib import Path

import yaml

from mcscan.evaluation import evaluate, parity

scan = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
truth = yaml.safe_load(Path(sys.argv[2]).read_text(encoding="utf-8"))
print(json.dumps(evaluate(scan["findings"], truth["resources"]), indent=2))
print("cross-cloud consistency:", parity(scan["findings"], truth.get("parity_cases", [])))
print("scan duration (s):", scan["duration_s"])
