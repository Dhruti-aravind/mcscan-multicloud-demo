"""Risk model: finding = severity x exposure x asset criticality; account = saturating 0-100."""
from __future__ import annotations

import math
from collections import defaultdict

SEVERITY_WEIGHT = {"CRITICAL": 10.0, "HIGH": 7.0, "MEDIUM": 4.0, "LOW": 1.0}
EXPOSURE_MULTIPLIER = {True: 2.0, False: 1.0}
CRITICALITY_MULTIPLIER = {"production": 1.5, "staging": 1.0, "dev": 0.5}
SATURATION_K = 50.0  # tunable: larger K = slower climb toward 100


def finding_score(severity: str, internet_exposed: bool, criticality: str = "production") -> float:
    try:
        return (
            SEVERITY_WEIGHT[severity]
            * EXPOSURE_MULTIPLIER[bool(internet_exposed)]
            * CRITICALITY_MULTIPLIER[criticality]
        )
    except KeyError as exc:
        raise ValueError(f"unknown severity/criticality: {exc}") from exc


def account_score(finding_scores: list[float], k: float = SATURATION_K) -> float:
    """100 * (1 - exp(-sum/k)). Monotonic, 0 when clean, never exceeds 100, no hard clipping."""
    total = sum(finding_scores)
    return round(100.0 * (1.0 - math.exp(-total / k)), 1)


def rollup_by_resource(findings: list) -> list[tuple[str, float]]:
    totals: dict[str, float] = defaultdict(float)
    for f in findings:
        totals[f"{f.provider}:{f.resource_id}"] += f.risk_score
    return sorted(totals.items(), key=lambda kv: kv[1], reverse=True)
