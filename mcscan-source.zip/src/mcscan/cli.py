"""Command line interface:  mcscan scan --provider aws --format cli json html"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from rich.console import Console

from .collectors.base import Collector
from .reporting import render_cli, write_html, write_json, write_sarif
from .rules import DEFAULT_RULES_DIR, RuleEngine, RuleError, load_rules
from .scanner import run_scan

SEVERITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="mcscan", description="Multi-cloud misconfiguration scanner")
    sub = p.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="scan cloud accounts (read-only)")
    scan.add_argument("--provider", nargs="+", choices=["aws", "azure", "gcp"], required=True)
    scan.add_argument("--demo", choices=["baseline", "hardened"],
                      help="scan offline synthetic fixtures; no cloud credentials required")
    scan.add_argument("--region", nargs="*", help="AWS regions (default: session region)")
    scan.add_argument("--aws-endpoint-url", help="point boto3 at a mock server (testing only)")
    scan.add_argument("--azure-subscription-id")
    scan.add_argument("--gcp-project-id")
    scan.add_argument("--rules", default=str(DEFAULT_RULES_DIR), help="rules directory")
    scan.add_argument("--criticality", choices=["production", "staging", "dev"], default="production")
    scan.add_argument("--format", nargs="+", choices=["cli", "json", "html", "sarif"], default=["cli"])
    scan.add_argument("--out", default="reports", help="output directory for json/html")
    scan.add_argument("--history-db", help="SQLite file for drift tracking (optional)")
    scan.add_argument("--fail-on", choices=SEVERITIES, help="exit 2 if any finding >= severity")

    lint = sub.add_parser("rules", help="list or lint rules")
    lint.add_argument("action", choices=["list", "lint"])
    lint.add_argument("--rules", default=str(DEFAULT_RULES_DIR))
    return p


def _build_collectors(args: argparse.Namespace) -> list[Collector]:
    if args.demo:
        from .demo import DemoCollector

        return [DemoCollector(p, args.demo == "hardened") for p in dict.fromkeys(args.provider)]
    collectors: list[Collector] = []
    for provider in args.provider:
        if provider == "aws":
            from .collectors.aws import AwsCollector

            collectors.append(AwsCollector(regions=args.region, endpoint_url=args.aws_endpoint_url))
        elif provider == "azure":
            from .collectors.azure import AzureCollector

            if not args.azure_subscription_id:
                raise SystemExit("--azure-subscription-id is required for azure")
            collectors.append(AzureCollector(args.azure_subscription_id))
        elif provider == "gcp":
            from .collectors.gcp import GcpCollector

            if not args.gcp_project_id:
                raise SystemExit("--gcp-project-id is required for gcp")
            collectors.append(GcpCollector(args.gcp_project_id))
    return collectors


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    console = Console()
    try:
        rules = load_rules(args.rules)
    except RuleError as exc:
        console.print(f"[red]rule error:[/red] {exc}")
        return 1
    if args.command == "rules":
        if args.action == "lint":
            console.print(f"[green]OK[/green] {len(rules)} rules loaded and linted")
        else:
            for r in rules:
                console.print(f"{r.id:9} {r.severity.value:9} {','.join(r.providers):14} {r.title}")
        return 0

    result = run_scan(_build_collectors(args), RuleEngine(rules), args.criticality)
    if args.demo:
        result.validation_mode = "offline"
        console.print("[yellow]OFFLINE DEMO: synthetic fixtures; no cloud API calls.[/yellow]")
    out = Path(args.out)
    if set(args.format) & {"json", "html", "sarif"}:
        out.mkdir(parents=True, exist_ok=True)
    if "cli" in args.format:
        render_cli(result, console)
    if "json" in args.format:
        console.print(f"wrote {write_json(result, out / f'{result.scan_id}.json')}")
    if "html" in args.format:
        console.print(f"wrote {write_html(result, out / f'{result.scan_id}.html')}")
    if "sarif" in args.format:
        console.print(f"wrote {write_sarif(result, out / f'{result.scan_id}.sarif')}")
    if args.history_db:
        from .history import diff_last_two, record

        record(args.history_db, result)
        d = diff_last_two(args.history_db)
        console.print(f"drift: {len(d['new'])} new, {len(d['resolved'])} resolved since previous scan")
    if args.fail_on:
        threshold = SEVERITIES.index(args.fail_on)
        if any(SEVERITIES.index(f.severity) >= threshold for f in result.findings):
            return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
