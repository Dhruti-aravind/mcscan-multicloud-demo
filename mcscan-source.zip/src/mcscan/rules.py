"""YAML rule loader + sandboxed evaluator. Adding coverage = adding a YAML file."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from simpleeval import EvalWithCompoundTypes, InvalidExpression, NameNotDefined

from .models import BENIGN_DEFAULTS, PROVIDERS, SCHEMA, Resource, Severity

DEFAULT_RULES_DIR = Path(__file__).parent / "rules"
RULE_ID_RE = re.compile(r"^[A-Z]{2,5}-\d{3}$")


class RuleError(ValueError):
    """A rule file is malformed. Raised at load time so typos never reach a scan."""


def port_exposed(ingress: list[dict[str, Any]], ports: list[int]) -> bool:
    """True if any world-open ingress entry covers any of `ports` (tcp/udp/all only)."""
    for entry in ingress:
        if entry.get("protocol") not in ("tcp", "udp", "all"):
            continue
        lo, hi = int(entry["from"]), int(entry["to"])
        if any(lo <= p <= hi for p in ports):
            return True
    return False


SAFE_FUNCTIONS = {"port_exposed": port_exposed, "len": len, "any": any, "all": all}


@dataclass(frozen=True)
class Rule:
    id: str
    title: str
    severity: Severity
    resource_type: str
    providers: tuple[str, ...]
    condition: str
    remediation: dict[str, str]
    compliance: dict[str, list[str]]
    tests: tuple[dict[str, Any], ...]

    def applies_to(self, resource: Resource) -> bool:
        return resource.resource_type == self.resource_type and resource.provider in self.providers

    def matches(self, props: dict[str, Any]) -> bool:
        evaluator = EvalWithCompoundTypes(names=dict(props), functions=SAFE_FUNCTIONS)
        return bool(evaluator.eval(self.condition))

    def remediation_for(self, provider: str) -> str:
        return self.remediation.get(provider) or self.remediation.get("default", "")


def _parse(path: Path) -> Rule:
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise RuleError(f"{path.name}: invalid YAML: {exc}") from exc
    if not isinstance(raw, dict):
        raise RuleError(f"{path.name}: top level must be a mapping")
    for key in ("id", "title", "severity", "resource_type", "providers", "condition"):
        if key not in raw:
            raise RuleError(f"{path.name}: missing required key {key!r}")
    if not RULE_ID_RE.match(str(raw["id"])):
        raise RuleError(f"{path.name}: id {raw['id']!r} must look like STOR-001")
    try:
        severity = Severity(str(raw["severity"]).upper())
    except ValueError as exc:
        raise RuleError(f"{path.name}: bad severity {raw['severity']!r}") from exc
    if raw["resource_type"] not in SCHEMA:
        raise RuleError(f"{path.name}: unknown resource_type {raw['resource_type']!r}")
    providers = tuple(raw["providers"])
    if not providers or not set(providers) <= set(PROVIDERS):
        raise RuleError(f"{path.name}: providers must be a non-empty subset of {PROVIDERS}")
    remediation = raw.get("remediation", {})
    if isinstance(remediation, str):
        remediation = {"default": remediation.strip()}
    rule = Rule(
        id=raw["id"],
        title=raw["title"],
        severity=severity,
        resource_type=raw["resource_type"],
        providers=providers,
        condition=str(raw["condition"]).strip(),
        remediation={k: str(v).strip() for k, v in remediation.items()},
        compliance={k: list(v) for k, v in (raw.get("compliance") or {}).items()},
        tests=tuple(raw.get("tests") or ()),
    )
    # Lint: the condition must evaluate cleanly against a benign resource of its type.
    try:
        rule.matches(BENIGN_DEFAULTS[rule.resource_type])
    except (NameNotDefined, InvalidExpression, SyntaxError, TypeError, KeyError) as exc:
        raise RuleError(f"{path.name}: condition does not evaluate: {exc}") from exc
    return rule


def load_rules(rules_dir: Path | str = DEFAULT_RULES_DIR) -> list[Rule]:
    rules: list[Rule] = []
    seen: set[str] = set()
    for path in sorted(Path(rules_dir).glob("*.yaml")):
        rule = _parse(path)
        if rule.id in seen:
            raise RuleError(f"duplicate rule id {rule.id} ({path.name})")
        seen.add(rule.id)
        rules.append(rule)
    if not rules:
        raise RuleError(f"no rules found in {rules_dir}")
    return rules


class RuleEngine:
    def __init__(self, rules: list[Rule]):
        self.rules = rules

    def evaluate(self, resource: Resource) -> tuple[list[Rule], list[str]]:
        """Return (rules that matched, evaluation errors). Never raises on a bad resource."""
        matched: list[Rule] = []
        errors: list[str] = []
        for rule in self.rules:
            if not rule.applies_to(resource):
                continue
            try:
                if rule.matches(resource.properties):
                    matched.append(rule)
            except (NameNotDefined, InvalidExpression, TypeError, KeyError) as exc:
                errors.append(f"rule {rule.id} on {resource.resource_id}: {exc}")
        return matched, errors
