"""Run `python -m mcscan.web --demo` for a local demonstration."""
import argparse
import getpass
from pathlib import Path

import uvicorn

from .app import create_app
from .store import Store


def main():
    parser = argparse.ArgumentParser(description="mcscan dashboard (offline release)")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--db")
    parser.add_argument("--demo", action="store_true", help="seed local demonstration accounts")
    parser.add_argument("--init-admin", action="store_true")
    parser.add_argument("--email")
    parser.add_argument("--name", default="Administrator")
    args = parser.parse_args()
    if args.demo and args.host not in ("localhost", "127.0.0.1", "::1"):
        parser.error("Demo accounts are restricted to a loopback host. Use --init-admin for deployment.")
    path = Path(args.db or (".data/demo.db" if args.demo else ".data/app.db"))
    store = Store(path)
    if args.init_admin:
        if not args.email:
            parser.error("--email is required with --init-admin")
        password = getpass.getpass("Administrator password (12+ characters): ")
        if len(password) < 12 or password != getpass.getpass("Confirm password: "):
            parser.error("Passwords must match and contain at least 12 characters")
        from .app import NewUser
        body = NewUser(email=args.email, name=args.name, password=password)
        with store.connect() as con:
            if con.execute("SELECT 1 FROM app_users WHERE role='admin'").fetchone():
                parser.error("An administrator already exists in this database")
        store.add_user(body.email, body.name, body.password, "admin")
        print("Administrator created. Start with: python -m mcscan.web")
        return
    if args.demo:
        with store.connect() as con:
            empty = not con.execute("SELECT 1 FROM app_users").fetchone()
        if empty:
            store.add_user("admin@mcscan.local", "Alex Morgan", "Mcscan-Demo-2026!", "admin")
            store.add_user("analyst@mcscan.local", "Jamie Chen", "Analyst-Demo-2026!")
        print("Local demo: admin@mcscan.local / Mcscan-Demo-2026!")
        print("Member: analyst@mcscan.local / Analyst-Demo-2026!")
    uvicorn.run(create_app(path, demo=args.demo), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
