"""Authenticated, offline-first web application for mcscan."""
