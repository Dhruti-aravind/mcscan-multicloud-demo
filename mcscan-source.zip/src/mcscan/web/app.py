"""Same-origin API: opaque cookie sessions, CSRF protection and per-user scan isolation.

Live scanning is deliberately unavailable in this web release. The supplied CLI
retains live collectors; enabling a multi-user live API needs per-user identities.
"""
from __future__ import annotations

import csv
import hmac
import io
import json
import os
import re
import secrets
import time
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Literal
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from starlette.middleware.trustedhost import TrustedHostMiddleware

from ..demo import DemoCollector
from ..models import Finding
from ..reporting import write_html, write_sarif
from ..rules import RuleEngine, load_rules
from ..scanner import ScanResult, run_scan
from .store import (
    configured_store,
    integrity_errors,
    password_hash,
    password_matches,
    public_user,
    token_hash,
)

SESSION_SECONDS = 12 * 60 * 60
COOKIE = "mcscan_session"
PROJECT_ROOT = Path(__file__).resolve().parents[3]


class Login(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=256)


class NewUser(Login):
    name: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=12, max_length=256)

    @field_validator("email")
    @classmethod
    def valid_email(cls, value):
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
            raise ValueError("Enter a valid email address")
        return value.strip().lower()

    @field_validator("name")
    @classmethod
    def valid_name(cls, value):
        if not value.strip():
            raise ValueError("Name is required")
        return value.strip()


class UserState(BaseModel):
    active: bool


class PasswordChange(BaseModel):
    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=12, max_length=256)


class ScanRequest(BaseModel):
    providers: list[Literal["aws", "azure", "gcp"]] = Field(min_length=1, max_length=3)
    scenario: Literal["baseline", "hardened"] = "baseline"
    criticality: Literal["production", "staging", "dev"] = "production"
    mode: Literal["offline"] = "offline"

    @field_validator("providers")
    @classmethod
    def unique_providers(cls, value):
        if len(value) != len(set(value)):
            raise ValueError("Choose each provider once")
        return sorted(value)


def finding_key(f):
    return f"{f['provider']}|{f['resource_id']}|{f['rule_id']}"


def create_app(db_path=None, demo=False, frontend_dir=None):
    store = configured_store(db_path)
    engine = RuleEngine(load_rules())
    app = FastAPI(title="mcscan", version="1.0.0", docs_url=None, redoc_url=None)
    app.state.store = store
    hosts = os.getenv("MCSCAN_ALLOWED_HOSTS", "localhost,127.0.0.1,testserver").split(",")
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)
    secure = os.getenv("MCSCAN_SECURE_COOKIES", "0") == "1"

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            origin = request.headers.get("origin")
            if (request.headers.get("sec-fetch-site") == "cross-site"
                    or (origin and urlsplit(origin).netloc != request.headers.get("host"))):
                return Response("Cross-origin request rejected", status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; font-src 'self'; connect-src 'self'; "
            "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        )
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    def current_user(request: Request):
        token = request.cookies.get(COOKIE, "")
        with store.connect() as con:
            row = con.execute(
                "SELECT u.*,s.csrf,s.token_hash FROM app_sessions s JOIN app_users u "
                "ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1",
                (token_hash(token), time.time()),
            ).fetchone()
        if not row:
            raise HTTPException(401, "Sign in to continue")
        if (request.method not in ("GET", "HEAD", "OPTIONS")
                and not hmac.compare_digest(request.headers.get("x-csrf-token", ""), row["csrf"])):
            raise HTTPException(403, "Session verification failed; refresh and try again")
        return dict(row)

    def admin(user=Depends(current_user)):
        if user["role"] != "admin":
            raise HTTPException(403, "Administrator access required")
        return user

    @app.get("/api/health")
    def health():
        return {"status": "ok", "mode": "offline", "demo_accounts": demo}

    @app.post("/api/auth/login")
    def login(body: Login, request: Request, response: Response):
        email = body.email.strip().lower()
        address = request.client.host if request.client else "unknown"
        keys = [token_hash(f"ip:{address}"), token_hash(f"email:{email}")]
        now = time.time()
        with store.connect() as con:
            con.execute("DELETE FROM app_attempts WHERE created_at<?", (now - 300,))
            count = con.execute("SELECT COUNT(*) AS attempts FROM app_attempts WHERE key IN (?,?)", keys).fetchone()["attempts"]
            if count >= 20:
                raise HTTPException(429, "Too many attempts. Try again in five minutes.")
            con.executemany("INSERT INTO app_attempts VALUES (?,?)", [(k, now) for k in keys])
            row = con.execute("SELECT * FROM app_users WHERE email=?", (email,)).fetchone()
        valid = password_matches(body.password, row["password_hash"] if row else store.dummy_hash)
        if not valid or not row or not row["active"]:
            raise HTTPException(401, "Email or password is incorrect")
        token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        with store.connect() as con:
            con.execute("DELETE FROM app_sessions WHERE expires_at<?", (now,))
            # Rotate a pre-existing session on sign-in.
            con.execute("DELETE FROM app_sessions WHERE token_hash=?",
                        (token_hash(request.cookies.get(COOKIE, "")),))
            con.execute("INSERT INTO app_sessions VALUES (?,?,?,?)",
                        (token_hash(token), row["id"], csrf, now + SESSION_SECONDS))
            con.execute("DELETE FROM app_attempts WHERE key IN (?,?)", keys)
        response.set_cookie(COOKIE, token, httponly=True, secure=secure,
                            samesite="strict", max_age=SESSION_SECONDS, path="/")
        store.audit(row["id"], "signed_in")
        return {"user": public_user(row), "csrf": csrf}

    @app.get("/api/auth/me")
    def me(user=Depends(current_user)):
        return {"user": public_user(user), "csrf": user["csrf"]}

    @app.post("/api/auth/logout")
    def logout(response: Response, user=Depends(current_user)):
        with store.connect() as con:
            con.execute("DELETE FROM app_sessions WHERE token_hash=?", (user["token_hash"],))
        response.delete_cookie(COOKIE, path="/")
        return {"ok": True}

    @app.post("/api/auth/password")
    def change_password(body: PasswordChange, response: Response, user=Depends(current_user)):
        if not password_matches(body.current_password, user["password_hash"]):
            raise HTTPException(400, "Current password is incorrect")
        with store.connect() as con:
            con.execute("UPDATE app_users SET password_hash=? WHERE id=?",
                        (password_hash(body.new_password), user["id"]))
            con.execute("DELETE FROM app_sessions WHERE user_id=?", (user["id"],))
        response.delete_cookie(COOKIE, path="/")
        store.audit(user["id"], "password_changed")
        return {"ok": True}

    @app.get("/api/users")
    def users(user=Depends(admin)):
        with store.connect() as con:
            rows = con.execute(
                "SELECT u.*, (SELECT COUNT(*) FROM app_scans s WHERE s.user_id=u.id) "
                "AS scan_count FROM app_users u ORDER BY role,created_at"
            ).fetchall()
        return [{**public_user(row), "scan_count": row["scan_count"]} for row in rows]

    @app.post("/api/users", status_code=201)
    def create_user(body: NewUser, user=Depends(admin)):
        try:
            member = store.add_user(body.email, body.name, body.password)
        except integrity_errors():
            raise HTTPException(409, "An account already uses this email") from None
        store.audit(user["id"], "member_created", member["id"])
        return member

    @app.patch("/api/users/{uid}")
    def update_user(uid: str, body: UserState, user=Depends(admin)):
        with store.connect() as con:
            row = con.execute("SELECT * FROM app_users WHERE id=?", (uid,)).fetchone()
            if not row:
                raise HTTPException(404, "User not found")
            if row["role"] == "admin":
                raise HTTPException(400, "The single administrator must remain active")
            con.execute("UPDATE app_users SET active=? WHERE id=?", (body.active, uid))
            if not body.active:
                con.execute("DELETE FROM app_sessions WHERE user_id=?", (uid,))
        store.audit(user["id"], "member_enabled" if body.active else "member_disabled", uid)
        return {"ok": True}

    @app.get("/api/audit")
    def audit_log(user=Depends(admin)):
        with store.connect() as con:
            rows = con.execute(
                "SELECT a.*,u.name AS user_name FROM app_audit a LEFT JOIN app_users u "
                "ON a.user_id=u.id ORDER BY a.id DESC LIMIT 100"
            ).fetchall()
        return [dict(row) for row in rows]

    @app.get("/api/rules")
    def rules(user=Depends(current_user)):
        return [{"id": r.id, "title": r.title, "severity": r.severity.value,
                 "resource_type": r.resource_type, "providers": r.providers,
                 "condition": r.condition, "remediation": r.remediation,
                 "tests": len(r.tests), "compliance": r.compliance,
                 "coverage": "AWS only" if r.id in ("ENC-001", "ENC-002", "NET-003")
                 else "AWS / Azure / GCP"} for r in engine.rules]

    @app.get("/api/scans")
    def scans(user=Depends(current_user)):
        return [{k: v for k, v in s.items() if k not in ("resources", "findings")}
                for s in store.scans(user["id"])]

    @app.post("/api/scans", status_code=201)
    def scan(body: ScanRequest, user=Depends(current_user)):
        collectors = [DemoCollector(p, body.scenario == "hardened") for p in body.providers]
        result = run_scan(collectors, engine, body.criticality)
        result.validation_mode = "offline"
        payload = result.to_dict()
        previous = next((s for s in store.scans(user["id"])
                         if s["providers"] == body.providers
                         and s["criticality"] == body.criticality), None)
        current = {finding_key(f) for f in payload["findings"]}
        old = {finding_key(f) for f in previous["findings"]} if previous else set()
        payload.update({
            "mode": "offline", "scenario": body.scenario, "status": "completed",
            "resources": [asdict(r) for c in collectors for r in c.resources],
            "severity_counts": result.severity_counts(), "finding_count": len(result.findings),
            "drift": {"previous_scan_id": previous["scan_id"] if previous else None,
                      "new": sorted(current - old) if previous else [],
                      "resolved": sorted(old - current), "unchanged": len(current & old)},
        })
        with store.connect() as con:
            con.execute("INSERT INTO app_scans VALUES (?,?,?,?)",
                        (result.scan_id, user["id"], time.time(), json.dumps(payload)))
        store.audit(user["id"], "scan_completed", result.scan_id)
        return payload

    def require_scan(sid, user):
        payload = store.scan(sid, user)
        if not payload:
            raise HTTPException(404, "Scan not found")
        return payload

    @app.get("/api/scans/{sid}")
    def get_scan(sid: str, user=Depends(current_user)):
        return require_scan(sid, user)

    @app.get("/api/scans/{sid}/export/{kind}")
    def export(sid: str, kind: Literal["json", "html", "sarif", "csv"],
               user=Depends(current_user)):
        payload = require_scan(sid, user)
        if kind == "json":
            content, mime = json.dumps(payload, indent=2), "application/json"
        elif kind == "csv":
            out = io.StringIO()
            fields = ["rule_id", "severity", "provider", "resource_name", "resource_id",
                      "region", "risk_score", "remediation"]
            writer = csv.DictWriter(out, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(payload["findings"])
            content, mime = out.getvalue(), "text/csv"
        else:
            base = {k: payload[k] for k in ScanResult.__dataclass_fields__}
            base["findings"] = [Finding(**f) for f in base["findings"]]
            result = ScanResult(**base)
            with TemporaryDirectory() as temp:
                path = Path(temp) / f"report.{kind}"
                (write_html if kind == "html" else write_sarif)(result, path)
                content = path.read_text(encoding="utf-8")
            if kind == "sarif":
                document = json.loads(content)
                document["runs"][0]["properties"] = {"mode": "offline", "scenario": payload["scenario"]}
                content = json.dumps(document, indent=2)
            mime = "text/html" if kind == "html" else "application/sarif+json"
        store.audit(user["id"], "report_exported", f"{sid}:{kind}")
        return Response(content, media_type=mime, headers={
            "Content-Disposition": f'attachment; filename="mcscan-{sid}.{kind}"',
        })

    ui = Path(frontend_dir or os.getenv("MCSCAN_FRONTEND_DIR",
                                      str(PROJECT_ROOT / "frontend" / "dist")))
    if (ui / "assets").exists():
        app.mount("/assets", StaticFiles(directory=ui / "assets"), name="assets")

    @app.get("/{path:path}")
    def frontend(path: str):
        if path.startswith("api/"):
            raise HTTPException(404, "Endpoint not found")
        if not (ui / "index.html").exists():
            raise HTTPException(503, "Build the frontend first: cd frontend && npm ci && npm run build")
        return FileResponse(ui / "index.html")

    return app
