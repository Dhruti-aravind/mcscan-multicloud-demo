"""Deterministic offline resources. No SDK client or cloud credential is used.

Azure/GCP fixtures pass through the same pure normalizers as live collection.
AWS fixtures describe normalized synthetic resources, not a real AWS account.
"""
from __future__ import annotations

from copy import deepcopy

from .collectors.azure import nsg_world_ingress, role_flags, storage_public_flags
from .collectors.base import Collector
from .collectors.gcp import binding_flags, bucket_public_flags, firewall_world_ingress
from .models import BENIGN_DEFAULTS, Resource

ACCOUNTS = {"aws": "123456789012", "azure": "demo-subscription", "gcp": "mcscan-demo-project"}
REGIONS = {"aws": "us-east-1", "azure": "eastus", "gcp": "us-central1"}


class DemoCollector(Collector):
    def __init__(self, provider: str, hardened: bool = False):
        super().__init__()
        if provider not in ACCOUNTS:
            raise ValueError("Unsupported demo provider")
        self.provider = provider
        self.hardened = hardened
        self.resources: list[Resource] = []

    def collect(self):
        p = self.provider
        self.resources = []

        def resource(kind, name, overrides=None):
            props = deepcopy(BENIGN_DEFAULTS[kind])
            props.update(overrides or {})
            if self.hardened:
                props = deepcopy(BENIGN_DEFAULTS[kind])
            r = Resource(p, kind, f"demo:{p}:{kind}:{name}", name, REGIONS[p], ACCOUNTS[p],
                         props, {"project": "mcscan", "environment": "demo"})
            self.resources.append(r)
            return r

        for name, public in (("public-assets", True), ("private-archive", False),
                             ("protected-logs", False)):
            if p == "azure":
                read, write = storage_public_flags(
                    {"allow_blob_public_access": public},
                    [{"public_access": "Blob" if public else "None"}],
                )
            elif p == "gcp":
                read, write = bucket_public_flags(
                    [{"role": "roles/storage.objectViewer", "members": ["allUsers"]}],
                    pap_enforced=not public,
                )
            else:
                read, write = public, False
            yield resource("storage_bucket", f"{p}-{name}",
                           {"public_read": read, "public_write": write,
                            "internet_exposed": read or write})

        for name, port in (("open-ssh", 22), ("open-postgres", 5432), ("public-https", 443)):
            if p == "azure":
                world = nsg_world_ingress([{
                    "direction": "Inbound", "access": "Allow", "protocol": "Tcp",
                    "source_address_prefix": "Internet", "destination_port_range": str(port),
                }])
            elif p == "gcp":
                world = firewall_world_ingress({
                    "direction": "INGRESS", "source_ranges": ["0.0.0.0/0"],
                    "allowed": [{"ip_protocol": "tcp", "ports": [str(port)]}],
                })
            else:
                world = [{"protocol": "tcp", "from": port, "to": port}]
            yield resource("firewall", f"{p}-{name}",
                           {"world_ingress": world, "internet_exposed": bool(world)})

        for name, kind in (("admin-all", "admin"), ("storage-wide", "service"),
                           ("readonly", "reader")):
            if p == "azure":
                action = {"admin": "*", "service": "Microsoft.Storage/*",
                          "reader": "Microsoft.Storage/storageAccounts/read"}[kind]
                admin, service = role_flags({"permissions": [{"actions": [action]}]})
            elif p == "gcp":
                role = {"admin": "roles/owner", "service": "roles/editor",
                        "reader": "roles/viewer"}[kind]
                admin, service = binding_flags(role)
            else:
                admin, service = kind == "admin", kind == "service"
            yield resource("iam_policy", f"{p}-{name}",
                           {"allows_admin": admin, "allows_service_wildcard_on_all": service})

        for name, encrypted in (("data-volume", p != "aws"), ("backup-volume", True)):
            yield resource("block_volume", f"{p}-{name}", {"encrypted_at_rest": encrypted})
        if p == "aws":
            yield resource("database", "aws-customer-db", {
                "encrypted_at_rest": False, "publicly_accessible": True, "internet_exposed": True,
            })
