"""Orchestrator: collect -> validate -> detect -> score. Provider-agnostic from here down."""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

from . import __version__
from .collectors.base import Collector
from .models import Finding, SchemaError
from .risk import account_score, finding_score
from .rules import RuleEngine


@dataclass
class ScanResult:
    scan_id: str
    tool_version: str
    started_at: str
    duration_s: float
    criticality: str
    providers: list[str]
    resources_scanned: int
    resources_by_type: dict[str, int]
    findings: list[Finding]
    errors: list[str]
    account_score: float
    score_by_provider: dict[str, float] = field(default_factory=dict)
    validation_mode: str = "live"

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["findings"] = [f.to_dict() for f in self.findings]
        return d

    def severity_counts(self) -> dict[str, int]:
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for f in self.findings:
            counts[f.severity] += 1
        return counts


def run_scan(collectors: list[Collector], engine: RuleEngine, criticality: str = "production"):
    started = datetime.now(timezone.utc)
    t0 = time.perf_counter()
    findings: list[Finding] = []
    errors: list[str] = []
    by_type: dict[str, int] = {}
    total = 0
    for collector in collectors:
        for resource in collector.collect():
            try:
                resource.validate()
            except SchemaError as exc:  # a collector bug is surfaced, never swallowed
                errors.append(f"schema: {exc}")
                continue
            total += 1
            by_type[resource.resource_type] = by_type.get(resource.resource_type, 0) + 1
            matched, rule_errors = engine.evaluate(resource)
            errors.extend(rule_errors)
            exposed = bool(resource.properties.get("internet_exposed"))
            for rule in matched:
                findings.append(
                    Finding(
                        rule_id=rule.id,
                        title=rule.title,
                        severity=rule.severity.value,
                        provider=resource.provider,
                        resource_type=resource.resource_type,
                        resource_id=resource.resource_id,
                        resource_name=resource.name,
                        region=resource.region,
                        account_id=resource.account_id,
                        risk_score=finding_score(rule.severity.value, exposed, criticality),
                        internet_exposed=exposed,
                        remediation=rule.remediation_for(resource.provider),
                        compliance=rule.compliance,
                        evidence={k: v for k, v in resource.properties.items()},
                    )
                )
        errors.extend(collector.errors)
    findings.sort(key=lambda f: (-f.risk_score, f.rule_id, f.resource_id))
    providers = sorted({c.provider for c in collectors})
    return ScanResult(
        scan_id=str(uuid.uuid4()),
        tool_version=__version__,
        started_at=started.isoformat(),
        duration_s=round(time.perf_counter() - t0, 3),
        criticality=criticality,
        providers=providers,
        resources_scanned=total,
        resources_by_type=by_type,
        findings=findings,
        errors=errors,
        account_score=account_score([f.risk_score for f in findings]),
        score_by_provider={
            p: account_score([f.risk_score for f in findings if f.provider == p]) for p in providers
        },
    )
