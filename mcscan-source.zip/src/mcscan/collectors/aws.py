"""AWS collector (boto3). READ-ONLY: only get_/list_/describe_ calls are ever made."""
from __future__ import annotations

import re
from collections.abc import Callable, Iterator
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

from ..models import Resource
from .base import Collector

_CONFIG = Config(
    retries={"mode": "adaptive", "max_attempts": 8},  # backoff on throttling
    user_agent_extra="mcscan/0.1 read-only",
)
PUBLIC_GRANTEES = {
    "http://acs.amazonaws.com/groups/global/AllUsers",
    "http://acs.amazonaws.com/groups/global/AuthenticatedUsers",
}
WORLD_CIDRS = {"0.0.0.0/0", "::/0"}
SERVICE_WILDCARD = re.compile(r"^[a-z0-9-]+:\*$", re.IGNORECASE)


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _optional(fn: Callable[[], Any], *ok_codes: str) -> Any:
    """Call fn(); return None if AWS says the optional config simply does not exist."""
    try:
        return fn()
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") in ok_codes:
            return None
        raise


def policy_public_access(doc: dict[str, Any]) -> tuple[bool, bool]:
    """(public_read, public_write) from a bucket policy. Conditional statements are skipped
    (documented false-negative risk: a Condition may or may not restrict the principal)."""
    read = write = False
    for st in _as_list(doc.get("Statement")):
        if st.get("Effect") != "Allow" or "Condition" in st:
            continue
        principal = st.get("Principal")
        is_public = principal == "*" or (
            isinstance(principal, dict) and "*" in _as_list(principal.get("AWS"))
        )
        if not is_public:
            continue
        actions = [str(a).lower() for a in _as_list(st.get("Action"))]
        if any(a in ("*", "s3:*", "s3:listbucket") or a.startswith("s3:get") for a in actions):
            read = True
        if any(a in ("*", "s3:*") or a.startswith(("s3:put", "s3:delete")) for a in actions):
            write = True
    return read, write


def iam_document_flags(doc: dict[str, Any]) -> tuple[bool, bool]:
    """(allows_admin, allows_service_wildcard_on_all) evaluated PER STATEMENT."""
    admin = svc = False
    for st in _as_list(doc.get("Statement")):
        if st.get("Effect") != "Allow":
            continue
        actions = [str(a) for a in _as_list(st.get("Action"))]
        resources = [str(r) for r in _as_list(st.get("Resource"))]
        if "*" not in resources:
            continue
        if "*" in actions:
            admin = True
        elif any(SERVICE_WILDCARD.match(a) for a in actions):
            svc = True
    return admin, svc


def world_ingress_entries(permissions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    entries = []
    for perm in permissions:
        cidrs = [r.get("CidrIp") for r in perm.get("IpRanges", [])]
        cidrs += [r.get("CidrIpv6") for r in perm.get("Ipv6Ranges", [])]
        if not WORLD_CIDRS & set(filter(None, cidrs)):
            continue
        proto = str(perm.get("IpProtocol"))
        if proto == "-1":
            entries.append({"protocol": "all", "from": 0, "to": 65535})
        else:
            entries.append(
                {
                    "protocol": proto.lower(),
                    "from": perm.get("FromPort", 0),
                    "to": perm.get("ToPort", 65535),
                }
            )
    return entries


class AwsCollector(Collector):
    provider = "aws"

    def __init__(
        self,
        session: boto3.Session | None = None,
        regions: list[str] | None = None,
        endpoint_url: str | None = None,
    ) -> None:
        super().__init__()
        self.session = session or boto3.Session()
        self.regions = regions or [self.session.region_name or "us-east-1"]
        self.endpoint_url = endpoint_url
        self.account_id = "unknown"

    def _client(self, service: str, region: str | None = None) -> Any:
        return self.session.client(
            service,
            region_name=region or self.regions[0],
            endpoint_url=self.endpoint_url,
            config=_CONFIG,
        )

    def collect(self) -> Iterator[Resource]:
        try:
            self.account_id = self._client("sts").get_caller_identity()["Account"]
        except (ClientError, BotoCoreError) as exc:
            self.record_error("sts:get_caller_identity", exc)
        yield from self._guard("s3", self._s3())
        yield from self._guard("iam", self._iam())
        for region in self.regions:
            yield from self._guard(f"ec2-sg:{region}", self._security_groups(region))
            yield from self._guard(f"ebs:{region}", self._volumes(region))
            yield from self._guard(f"rds:{region}", self._databases(region))

    def _guard(self, label: str, gen: Iterator[Resource]) -> Iterator[Resource]:
        try:
            yield from gen
        except (ClientError, BotoCoreError) as exc:
            self.record_error(label, exc)

    # ---------------------------------------------------------------- S3
    def _s3(self) -> Iterator[Resource]:
        s3 = self._client("s3")
        for bucket in s3.list_buckets().get("Buckets", []):
            name = bucket["Name"]
            try:
                yield self._bucket(s3, name)
            except (ClientError, BotoCoreError) as exc:  # one bad bucket must not stop the scan
                self.record_error(f"s3:{name}", exc)

    def _bucket(self, s3: Any, name: str) -> Resource:
        loc = s3.get_bucket_location(Bucket=name).get("LocationConstraint") or "us-east-1"
        acl_read = acl_write = False
        for grant in s3.get_bucket_acl(Bucket=name).get("Grants", []):
            if grant.get("Grantee", {}).get("URI") in PUBLIC_GRANTEES:
                perm = grant.get("Permission")
                acl_read |= perm in ("READ", "FULL_CONTROL")
                acl_write |= perm in ("WRITE", "FULL_CONTROL")
        pab = _optional(
            lambda: s3.get_public_access_block(Bucket=name)["PublicAccessBlockConfiguration"],
            "NoSuchPublicAccessBlockConfiguration",
        ) or {}
        raw_policy = _optional(
            lambda: s3.get_bucket_policy(Bucket=name)["Policy"], "NoSuchBucketPolicy"
        )
        pol_read = pol_write = False
        if raw_policy:
            import json

            pol_read, pol_write = policy_public_access(json.loads(raw_policy))
        # Block Public Access overrides: IgnorePublicAcls neutralizes ACL grants,
        # RestrictPublicBuckets neutralizes public policies.
        if pab.get("IgnorePublicAcls"):
            acl_read = acl_write = False
        if pab.get("RestrictPublicBuckets"):
            pol_read = pol_write = False
        enc = _optional(
            lambda: s3.get_bucket_encryption(Bucket=name)["ServerSideEncryptionConfiguration"],
            "ServerSideEncryptionConfigurationNotFoundError",
        )
        algo = None
        if enc and enc.get("Rules"):
            algo = enc["Rules"][0]["ApplyServerSideEncryptionByDefault"].get("SSEAlgorithm")
        read, write = acl_read or pol_read, acl_write or pol_write
        return Resource(
            provider="aws",
            resource_type="storage_bucket",
            resource_id=f"arn:aws:s3:::{name}",
            name=name,
            region=loc,
            account_id=self.account_id,
            properties={
                "public_read": read,
                "public_write": write,
                "internet_exposed": read or write,
                "encryption_algorithm": algo,
                "block_public_access": pab,
            },
        )

    # --------------------------------------------------------------- IAM
    def _iam(self) -> Iterator[Resource]:
        iam = self._client("iam")
        for page in iam.get_paginator("list_policies").paginate(Scope="Local"):
            for pol in page["Policies"]:
                version = iam.get_policy_version(
                    PolicyArn=pol["Arn"], VersionId=pol["DefaultVersionId"]
                )
                admin, svc = iam_document_flags(version["PolicyVersion"]["Document"])
                yield Resource(
                    provider="aws",
                    resource_type="iam_policy",
                    resource_id=pol["Arn"],
                    name=pol["PolicyName"],
                    region="global",
                    account_id=self.account_id,
                    properties={
                        "allows_admin": admin,
                        "allows_service_wildcard_on_all": svc,
                        "internet_exposed": False,
                        "attachment_count": pol.get("AttachmentCount", 0),
                    },
                )

    # ------------------------------------------------------ EC2 / EBS / RDS
    def _security_groups(self, region: str) -> Iterator[Resource]:
        ec2 = self._client("ec2", region)
        for page in ec2.get_paginator("describe_security_groups").paginate():
            for sg in page["SecurityGroups"]:
                world = world_ingress_entries(sg.get("IpPermissions", []))
                yield Resource(
                    provider="aws",
                    resource_type="firewall",
                    resource_id=sg["GroupId"],
                    name=sg.get("GroupName", sg["GroupId"]),
                    region=region,
                    account_id=self.account_id,
                    properties={"world_ingress": world, "internet_exposed": bool(world)},
                    tags={t["Key"]: t["Value"] for t in sg.get("Tags", [])},
                )

    def _volumes(self, region: str) -> Iterator[Resource]:
        ec2 = self._client("ec2", region)
        for page in ec2.get_paginator("describe_volumes").paginate():
            for vol in page["Volumes"]:
                yield Resource(
                    provider="aws",
                    resource_type="block_volume",
                    resource_id=vol["VolumeId"],
                    name=vol["VolumeId"],
                    region=region,
                    account_id=self.account_id,
                    properties={
                        "encrypted_at_rest": bool(vol.get("Encrypted")),
                        "internet_exposed": False,
                        "attached": bool(vol.get("Attachments")),
                    },
                    tags={t["Key"]: t["Value"] for t in vol.get("Tags", [])},
                )

    def _databases(self, region: str) -> Iterator[Resource]:
        rds = self._client("rds", region)
        for page in rds.get_paginator("describe_db_instances").paginate():
            for db in page["DBInstances"]:
                public = bool(db.get("PubliclyAccessible"))
                yield Resource(
                    provider="aws",
                    resource_type="database",
                    resource_id=db["DBInstanceIdentifier"],
                    name=db["DBInstanceIdentifier"],
                    region=region,
                    account_id=self.account_id,
                    properties={
                        "encrypted_at_rest": bool(db.get("StorageEncrypted")),
                        "publicly_accessible": public,
                        "internet_exposed": public,
                        "engine": db.get("Engine"),
                    },
                )
