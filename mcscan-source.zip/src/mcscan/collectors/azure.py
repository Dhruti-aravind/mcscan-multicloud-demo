"""Azure collector. READ-ONLY (list_/get_ only). Pure normalizers are unit-tested with fixtures;
the thin fetch layer needs a real subscription to verify (Phase 4)."""
from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from ..models import Resource
from .base import Collector

WORLD_SOURCES = {"*", "0.0.0.0/0", "::/0", "internet", "any"}


def flat(obj: Any) -> dict[str, Any]:
    """SDK model -> dict, merging a nested 'properties' block (SDK versions differ)."""
    d = obj.as_dict() if hasattr(obj, "as_dict") else dict(obj)
    props = d.get("properties")
    return {**d, **props} if isinstance(props, dict) else d


def _ports(spec: str) -> tuple[int, int]:
    spec = str(spec).strip()
    if spec in ("*", ""):
        return 0, 65535
    if "-" in spec:
        lo, hi = spec.split("-", 1)
        return int(lo), int(hi)
    return int(spec), int(spec)


def nsg_world_ingress(rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Inbound Allow rules whose source is the internet. Priority/Deny interplay is ignored
    (documented false-positive risk: a higher-priority Deny could neutralize an Allow)."""
    out: list[dict[str, Any]] = []
    for r in rules:
        r = flat(r)
        if str(r.get("direction", "")).lower() != "inbound" or str(r.get("access", "")).lower() != "allow":
            continue
        sources = [r.get("source_address_prefix")] + list(r.get("source_address_prefixes") or [])
        if not any(str(s).lower() in WORLD_SOURCES for s in sources if s):
            continue
        proto = str(r.get("protocol", "*")).lower()
        proto = "all" if proto == "*" else proto
        port_specs = [r.get("destination_port_range")] + list(r.get("destination_port_ranges") or [])
        for spec in filter(None, port_specs):
            lo, hi = _ports(spec)
            out.append({"protocol": proto, "from": lo, "to": hi})
    return out


def storage_public_flags(account: dict[str, Any], containers: list[dict[str, Any]]) -> tuple[bool, bool]:
    """(public_read, public_write). Azure anonymous access is read-only by design.
    Account setting None is treated as allowed (documented default) [Verify against current docs]."""
    account = flat(account)
    allowed = account.get("allow_blob_public_access")
    if allowed is False:
        return False, False
    public = any(str(flat(c).get("public_access", "None")).lower() in ("blob", "container") for c in containers)
    return public, False


def role_flags(role: dict[str, Any]) -> tuple[bool, bool]:
    """(allows_admin, allows_service_wildcard_on_all) for a custom role definition."""
    role = flat(role)
    admin = svc = False
    for perm in role.get("permissions") or []:
        for action in perm.get("actions") or []:
            if action == "*":
                admin = True
            elif str(action).endswith("/*"):
                svc = True
    return admin, svc


class AzureCollector(Collector):
    provider = "azure"

    def __init__(self, subscription_id: str, credential: Any = None, clients: dict[str, Any] | None = None):
        super().__init__()
        self.subscription_id = subscription_id
        self._credential = credential
        self._clients = clients or {}

    def _client(self, key: str) -> Any:
        if key not in self._clients:
            from azure.identity import DefaultAzureCredential

            cred = self._credential or DefaultAzureCredential()
            if key == "storage":
                from azure.mgmt.storage import StorageManagementClient as C
            elif key == "network":
                from azure.mgmt.network import NetworkManagementClient as C
            elif key == "auth":
                from azure.mgmt.authorization import AuthorizationManagementClient as C
            else:
                from azure.mgmt.compute import ComputeManagementClient as C
            self._clients[key] = C(cred, self.subscription_id)
        return self._clients[key]

    def collect(self) -> Iterator[Resource]:
        for label, gen in (
            ("storage", self._storage), ("nsg", self._nsgs), ("roles", self._roles), ("disks", self._disks)
        ):
            try:
                yield from gen()
            except Exception as exc:  # noqa: BLE001 - SDK raises many types; keep scanning
                self.record_error(label, exc)

    @staticmethod
    def _rg(resource_id: str) -> str:
        parts = resource_id.split("/")
        return parts[parts.index("resourceGroups") + 1] if "resourceGroups" in parts else ""

    def _storage(self) -> Iterator[Resource]:
        client = self._client("storage")
        for acct in client.storage_accounts.list():
            a = flat(acct)
            try:
                containers = list(client.blob_containers.list(self._rg(a["id"]), a["name"]))
            except Exception as exc:  # noqa: BLE001
                self.record_error(f"containers:{a['name']}", exc)
                containers = []
            read, write = storage_public_flags(a, [flat(c) for c in containers])
            yield Resource("azure", "storage_bucket", a["id"], a["name"], a.get("location", ""),
                           self.subscription_id,
                           {"public_read": read, "public_write": write, "internet_exposed": read or write,
                            "allow_blob_public_access": a.get("allow_blob_public_access")},
                           a.get("tags") or {})

    def _nsgs(self) -> Iterator[Resource]:
        for nsg in self._client("network").network_security_groups.list_all():
            n = flat(nsg)
            world = nsg_world_ingress(n.get("security_rules") or [])
            yield Resource("azure", "firewall", n["id"], n["name"], n.get("location", ""),
                           self.subscription_id, {"world_ingress": world, "internet_exposed": bool(world)},
                           n.get("tags") or {})

    def _roles(self) -> Iterator[Resource]:
        scope = f"/subscriptions/{self.subscription_id}"
        for role in self._client("auth").role_definitions.list(scope, filter="type eq 'CustomRole'"):
            r = flat(role)
            admin, svc = role_flags(r)
            yield Resource("azure", "iam_policy", r["id"], r.get("role_name") or r["name"], "global",
                           self.subscription_id,
                           {"allows_admin": admin, "allows_service_wildcard_on_all": svc,
                            "internet_exposed": False})

    def _disks(self) -> Iterator[Resource]:
        for disk in self._client("compute").disks.list():
            d = flat(disk)
            # Managed disks are always encrypted at rest (platform-managed key by default).
            yield Resource("azure", "block_volume", d["id"], d["name"], d.get("location", ""),
                           self.subscription_id,
                           {"encrypted_at_rest": True, "internet_exposed": False,
                            "encryption_type": (d.get("encryption") or {}).get("type")},
                           d.get("tags") or {})
