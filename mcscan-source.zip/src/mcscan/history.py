"""Optional drift tracking in SQLite (standard library, zero setup)."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from .scanner import ScanResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans(id TEXT PRIMARY KEY, started_at TEXT, score REAL, payload TEXT);
CREATE TABLE IF NOT EXISTS findings(scan_id TEXT, rule_id TEXT, provider TEXT, resource_id TEXT,
  severity TEXT, risk REAL, PRIMARY KEY(scan_id, rule_id, resource_id));
"""


def record(db: Path | str, result: ScanResult) -> None:
    con = sqlite3.connect(db)
    with con:
        con.executescript(SCHEMA)
        con.execute("INSERT INTO scans VALUES (?,?,?,?)", (result.scan_id, result.started_at,
                    result.account_score, json.dumps(result.severity_counts())))
        con.executemany("INSERT OR REPLACE INTO findings VALUES (?,?,?,?,?,?)",
                        [(result.scan_id, f.rule_id, f.provider, f.resource_id, f.severity, f.risk_score)
                         for f in result.findings])
    con.close()


def diff_last_two(db: Path | str) -> dict[str, list[tuple[str, str]]]:
    """Return {'new': [...], 'resolved': [...]} comparing the two most recent scans."""
    con = sqlite3.connect(db)
    ids = [r[0] for r in con.execute("SELECT id FROM scans ORDER BY started_at DESC LIMIT 2")]
    if len(ids) < 2:
        con.close()
        return {"new": [], "resolved": []}

    def keys(sid: str) -> set[tuple[str, str]]:
        return {(r[0], r[1]) for r in con.execute(
            "SELECT rule_id, resource_id FROM findings WHERE scan_id=?", (sid,))}

    cur, prev = keys(ids[0]), keys(ids[1])
    con.close()
    return {"new": sorted(cur - prev), "resolved": sorted(prev - cur)}
