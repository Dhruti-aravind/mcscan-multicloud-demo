"""CLI (rich), JSON and HTML reports. HTML is autoescaped: resource names are attacker-controlled."""
from __future__ import annotations

import json
from pathlib import Path

from jinja2 import Environment, PackageLoader
from rich.console import Console
from rich.table import Table

from ..risk import rollup_by_resource
from ..scanner import ScanResult

SEV_STYLE = {"CRITICAL": "bold red", "HIGH": "red", "MEDIUM": "yellow", "LOW": "cyan"}


def write_json(result: ScanResult, path: Path) -> Path:
    path.write_text(json.dumps(result.to_dict(), indent=2, default=str), encoding="utf-8")
    return path


def write_html(result: ScanResult, path: Path) -> Path:
    env = Environment(loader=PackageLoader("mcscan", "templates"), autoescape=True)
    html = env.get_template("report.html.j2").render(
        r=result, counts=result.severity_counts(), top=rollup_by_resource(result.findings)[:5]
    )
    path.write_text(html, encoding="utf-8")
    return path


def render_cli(result: ScanResult, console: Console | None = None) -> None:
    console = console or Console()
    counts = result.severity_counts()
    console.print(
        f"[bold]mcscan[/bold] {result.tool_version}  providers={','.join(result.providers)}  "
        f"resources={result.resources_scanned}  duration={result.duration_s}s"
    )
    console.print(
        f"Risk score: [bold]{result.account_score}[/bold]/100   "
        + "  ".join(f"[{SEV_STYLE[s]}]{s}={n}[/]" for s, n in counts.items())
    )
    table = Table(show_lines=False)
    for col in ("Sev", "Rule", "Provider", "Resource", "Score"):
        table.add_column(col)
    for f in result.findings:
        table.add_row(
            f"[{SEV_STYLE[f.severity]}]{f.severity}[/]",
            f.rule_id,
            f.provider,
            f.resource_name,
            f"{f.risk_score:.1f}",
        )
    console.print(table)
    for err in result.errors:
        console.print(f"[yellow]warning:[/yellow] {err}")


def write_sarif(result: ScanResult, path: Path) -> Path:
    """SARIF 2.1.0 so GitHub code scanning and other tools can ingest findings."""
    level = {"CRITICAL": "error", "HIGH": "error", "MEDIUM": "warning", "LOW": "note"}
    rules = {f.rule_id: f for f in result.findings}
    doc = {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": [{
            "properties": {"validation_mode": result.validation_mode},
            "tool": {"driver": {"name": "mcscan", "version": result.tool_version, "rules": [
                {"id": rid, "shortDescription": {"text": f.title}} for rid, f in sorted(rules.items())]}},
            "results": [{
                "ruleId": f.rule_id, "level": level[f.severity],
                "message": {"text": f"{f.title}: {f.resource_name}. {f.remediation}"},
                "locations": [{"logicalLocations": [{"name": f.resource_name, "kind": "resource",
                                                      "fullyQualifiedName": f"{f.provider}:{f.resource_id}"}]}],
            } for f in result.findings],
        }],
    }
    path.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    return path
