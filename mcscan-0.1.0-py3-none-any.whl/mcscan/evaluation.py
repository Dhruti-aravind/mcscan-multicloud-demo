"""Ground-truth evaluation: precision / recall / F1 per provider + cross-cloud consistency."""
from __future__ import annotations

from collections import defaultdict
from typing import Any

import yaml


def load_truth(path: str) -> list[dict[str, Any]]:
    """truth.yaml: list of {provider, name, expect: [RULE-IDS]} ; expect [] = negative control."""
    return yaml.safe_load(open(path, encoding="utf-8"))["resources"]


def evaluate(findings: list[dict[str, Any]], truth: list[dict[str, Any]], provider_scope: set[str] | None = None):
    expected = {(t["provider"], t["name"], r) for t in truth for r in t.get("expect", [])}
    known = {(t["provider"], t["name"]) for t in truth}
    # Only judge findings on resources the ground truth knows about (ignore pre-existing noise).
    got = {(f["provider"], f["resource_name"], f["rule_id"]) for f in findings
           if (f["provider"], f["resource_name"]) in known}
    providers = provider_scope or {p for p, _, _ in expected | got}
    per: dict[str, dict[str, float]] = {}
    for prov in sorted(providers | {"ALL"}):
        e = {x for x in expected if prov in ("ALL", x[0])}
        g = {x for x in got if prov in ("ALL", x[0])}
        tp, fp, fn = len(e & g), len(g - e), len(e - g)
        p = tp / (tp + fp) if tp + fp else 1.0
        r = tp / (tp + fn) if tp + fn else 1.0
        f1 = 2 * p * r / (p + r) if p + r else 0.0
        per[prov] = {"tp": tp, "fp": fp, "fn": fn, "precision": round(p, 3),
                     "recall": round(r, 3), "f1": round(f1, 3)}
    return per


def parity(findings: list[dict[str, Any]], cases: list[dict[str, Any]]) -> float:
    """cases: [{id, members: {aws: name, azure: name, gcp: name}, rule: RULE-ID, severity: SEV}].
    Consistency = share of cases where every listed provider yields that rule at that severity."""
    idx: dict[tuple[str, str], set[tuple[str, str]]] = defaultdict(set)
    for f in findings:
        idx[(f["provider"], f["resource_name"])].add((f["rule_id"], f["severity"]))
    ok = 0
    for c in cases:
        if all((c["rule"], c["severity"]) in idx[(prov, name)] for prov, name in c["members"].items()):
            ok += 1
    return round(ok / len(cases), 3) if cases else 1.0
