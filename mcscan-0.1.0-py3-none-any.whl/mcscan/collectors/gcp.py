"""GCP collector. READ-ONLY. Pure normalizers are unit-tested with fixtures; the thin fetch
layer needs a real project to verify (Phase 4)."""
from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from ..models import Resource
from .base import Collector

PUBLIC_MEMBERS = {"allUsers", "allAuthenticatedUsers"}
READ_ROLES = {"roles/storage.objectViewer", "roles/storage.legacyObjectReader",
              "roles/storage.legacyBucketReader", "roles/storage.objectAdmin", "roles/storage.admin"}
WRITE_ROLES = {"roles/storage.objectCreator", "roles/storage.legacyBucketWriter",
               "roles/storage.objectAdmin", "roles/storage.admin", "roles/storage.legacyBucketOwner"}
WORLD = {"0.0.0.0/0", "::/0"}


def bucket_public_flags(bindings: list[dict[str, Any]], pap_enforced: bool) -> tuple[bool, bool]:
    """Public Access Prevention 'enforced' blocks allUsers/allAuthenticatedUsers entirely."""
    if pap_enforced:
        return False, False
    read = write = False
    for b in bindings:
        if PUBLIC_MEMBERS & set(b.get("members", [])):
            role = b.get("role", "")
            read |= role in READ_ROLES
            write |= role in WRITE_ROLES
    return read, write


def firewall_world_ingress(fw: dict[str, Any]) -> list[dict[str, Any]]:
    if str(fw.get("direction", "INGRESS")).upper() != "INGRESS" or fw.get("disabled"):
        return []
    if not WORLD & set(fw.get("source_ranges") or []):
        return []
    out: list[dict[str, Any]] = []
    for allowed in fw.get("allowed") or []:
        proto = str(allowed.get("ip_protocol") or allowed.get("I_p_protocol") or "").lower()
        proto = "all" if proto == "all" else proto
        ports = allowed.get("ports") or []
        if proto in ("all",) or (not ports and proto in ("tcp", "udp")):
            out.append({"protocol": proto or "all", "from": 0, "to": 65535})
            continue
        for spec in ports:
            lo, _, hi = str(spec).partition("-")
            out.append({"protocol": proto, "from": int(lo), "to": int(hi or lo)})
    return out


def binding_flags(role: str) -> tuple[bool, bool]:
    """Primitive roles: owner = admin; editor = broad service-wide access."""
    return role == "roles/owner", role == "roles/editor"


class GcpCollector(Collector):
    provider = "gcp"

    def __init__(self, project_id: str, clients: dict[str, Any] | None = None):
        super().__init__()
        self.project_id = project_id
        self._clients = clients or {}

    def collect(self) -> Iterator[Resource]:
        for label, gen in (("gcs", self._buckets), ("firewall", self._firewalls),
                           ("iam", self._project_iam), ("disks", self._disks)):
            try:
                yield from gen()
            except Exception as exc:  # noqa: BLE001
                self.record_error(label, exc)

    def _buckets(self) -> Iterator[Resource]:
        client = self._clients.get("storage")
        if client is None:
            from google.cloud import storage

            client = storage.Client(project=self.project_id)
        for bucket in client.list_buckets():
            policy = bucket.get_iam_policy(requested_policy_version=3)
            bindings = [{"role": b["role"], "members": list(b["members"])} for b in policy.bindings]
            pap = (bucket.iam_configuration.public_access_prevention or "") == "enforced"
            read, write = bucket_public_flags(bindings, pap)
            yield Resource("gcp", "storage_bucket", f"gs://{bucket.name}", bucket.name,
                           (bucket.location or "").lower(), self.project_id,
                           {"public_read": read, "public_write": write, "internet_exposed": read or write,
                            "public_access_prevention": bucket.iam_configuration.public_access_prevention})

    def _firewalls(self) -> Iterator[Resource]:
        client = self._clients.get("firewalls")
        if client is None:
            from google.cloud import compute_v1

            client = compute_v1.FirewallsClient()
        from_dict = self._clients.get("to_dict") or _to_dict
        for fw in client.list(project=self.project_id):
            d = from_dict(fw)
            world = firewall_world_ingress(d)
            yield Resource("gcp", "firewall", str(d.get("id", d["name"])), d["name"], "global",
                           self.project_id, {"world_ingress": world, "internet_exposed": bool(world)})

    def _project_iam(self) -> Iterator[Resource]:
        client = self._clients.get("projects")
        if client is None:
            from google.cloud import resourcemanager_v3

            client = resourcemanager_v3.ProjectsClient()
        policy = client.get_iam_policy(request={"resource": f"projects/{self.project_id}"})
        for binding in policy.bindings:
            admin, svc = binding_flags(binding.role)
            if not (admin or svc):
                continue  # only primitive-role bindings are modeled
            yield Resource("gcp", "iam_policy", f"{self.project_id}:{binding.role}", binding.role, "global",
                           self.project_id,
                           {"allows_admin": admin, "allows_service_wildcard_on_all": svc,
                            "internet_exposed": False, "members": list(binding.members)})

    def _disks(self) -> Iterator[Resource]:
        client = self._clients.get("disks")
        if client is None:
            from google.cloud import compute_v1

            client = compute_v1.DisksClient()
        for _zone, scoped in client.aggregated_list(project=self.project_id):
            for disk in getattr(scoped, "disks", []) or []:
                # Persistent disks are always encrypted at rest (Google-managed key by default).
                yield Resource("gcp", "block_volume", str(disk.id), disk.name, _zone.split("/")[-1],
                               self.project_id, {"encrypted_at_rest": True, "internet_exposed": False})


def _to_dict(msg: Any) -> dict[str, Any]:
    return type(msg).to_dict(msg)
