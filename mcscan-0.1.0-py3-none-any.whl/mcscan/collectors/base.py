"""Collector contract. Collectors are READ-ONLY by design (enforced by tests/test_readonly_guard)."""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator

from ..models import Resource


class Collector(ABC):
    provider: str

    def __init__(self) -> None:
        self.errors: list[str] = []

    @abstractmethod
    def collect(self) -> Iterator[Resource]:
        """Yield normalized resources. Must only call read/list/describe/get APIs."""

    def record_error(self, where: str, exc: Exception) -> None:
        # A partial scan is reported honestly instead of crashing or silently under-reporting.
        self.errors.append(f"[{self.provider}] {where}: {type(exc).__name__}: {exc}")
