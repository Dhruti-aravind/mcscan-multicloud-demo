"""Normalized data model shared by every collector, the rule engine and the reports."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"

    @property
    def rank(self) -> int:
        return {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}[self.value]


PROVIDERS = ("aws", "azure", "gcp")

# The normalized schema contract: every collector MUST emit these properties for a type.
# Rules are written against these names, which is what makes one rule work on all clouds.
SCHEMA: dict[str, frozenset[str]] = {
    "storage_bucket": frozenset({"public_read", "public_write", "internet_exposed"}),
    "iam_policy": frozenset({"allows_admin", "allows_service_wildcard_on_all", "internet_exposed"}),
    "firewall": frozenset({"world_ingress", "internet_exposed"}),
    "block_volume": frozenset({"encrypted_at_rest", "internet_exposed"}),
    "database": frozenset({"encrypted_at_rest", "publicly_accessible", "internet_exposed"}),
}

# A "known good" resource per type. Used to lint rules and as the base for rule unit tests.
BENIGN_DEFAULTS: dict[str, dict[str, Any]] = {
    "storage_bucket": {"public_read": False, "public_write": False, "internet_exposed": False},
    "iam_policy": {
        "allows_admin": False,
        "allows_service_wildcard_on_all": False,
        "internet_exposed": False,
    },
    "firewall": {"world_ingress": [], "internet_exposed": False},
    "block_volume": {"encrypted_at_rest": True, "internet_exposed": False},
    "database": {
        "encrypted_at_rest": True,
        "publicly_accessible": False,
        "internet_exposed": False,
    },
}


class SchemaError(ValueError):
    """A collector produced a resource that violates the normalized schema."""


@dataclass
class Resource:
    provider: str
    resource_type: str
    resource_id: str
    name: str
    region: str
    account_id: str
    properties: dict[str, Any] = field(default_factory=dict)
    tags: dict[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        if self.provider not in PROVIDERS:
            raise SchemaError(f"unknown provider {self.provider!r}")
        required = SCHEMA.get(self.resource_type)
        if required is None:
            raise SchemaError(f"unknown resource_type {self.resource_type!r}")
        missing = required - self.properties.keys()
        if missing:
            raise SchemaError(
                f"{self.provider}/{self.resource_type}/{self.resource_id} missing {sorted(missing)}"
            )


@dataclass
class Finding:
    rule_id: str
    title: str
    severity: str
    provider: str
    resource_type: str
    resource_id: str
    resource_name: str
    region: str
    account_id: str
    risk_score: float
    internet_exposed: bool
    remediation: str
    compliance: dict[str, list[str]]
    evidence: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
