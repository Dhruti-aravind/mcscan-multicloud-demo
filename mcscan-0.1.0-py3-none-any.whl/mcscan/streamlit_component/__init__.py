"""Motion dashboard assets for Streamlit Components v2."""
